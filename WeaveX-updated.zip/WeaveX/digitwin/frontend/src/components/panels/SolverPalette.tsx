import { useEffect, useState } from "react";
import { Cpu, Route, Calendar, Swords, Dice, ChevronDown, ChevronRight, GripVertical } from "lucide-react";
import type { ReactNode } from "react";

interface SolverMeta {
  name: string;
  display_name: string;
  category: string;
  description: string;
  supported_problem_types: string[];
  supported_domains: string[];
  configurable_params: {
    name: string;
    type: string;
    min?: number;
    max?: number;
    default?: number | boolean | string;
    label: string;
    options?: string[];
  }[];
}

const CATEGORY_META: Record<
  string,
  { label: string; icon: ReactNode; color: string }
> = {
  classical: { label: "Classical (LP/MIP)", icon: <Cpu className="w-3.5 h-3.5" />, color: "#6366f1" },
  combinatorial: { label: "Combinatorial", icon: <Route className="w-3.5 h-3.5" />, color: "#06b6d4" },
  game_theory: { label: "Game theory", icon: <Swords className="w-3.5 h-3.5" />, color: "#f59e0b" },
  stochastic: { label: "Stochastic", icon: <Dice className="w-3.5 h-3.5" />, color: "#10b981" },
  evolutionary: { label: "Evolutionary", icon: <Cpu className="w-3.5 h-3.5" />, color: "#ec4899" },
  reinforcement_learning: { label: "Reinforcement learning", icon: <Cpu className="w-3.5 h-3.5" />, color: "#8b5cf6" },
};

interface Props {
  domain?: string;
  onDragStart?: (solver: SolverMeta) => void;
}

export default function SolverPalette({ domain, onDragStart }: Props) {
  const [solvers, setSolvers] = useState<SolverMeta[]>([]);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const url = domain
      ? `/api/optimizer/palette/${domain}`
      : "/api/optimizer/palette";

    fetch(url)
      .then((r) => r.json())
      .then((data) => {
        setSolvers(data.data || []);
        // Expand all categories by default
        const cats: Record<string, boolean> = {};
        for (const s of data.data || []) {
          cats[s.category] = true;
        }
        setExpanded(cats);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [domain]);

  // Group by category
  const grouped: Record<string, SolverMeta[]> = {};
  for (const s of solvers) {
    (grouped[s.category] ??= []).push(s);
  }

  const toggleCat = (cat: string) =>
    setExpanded((prev) => ({ ...prev, [cat]: !prev[cat] }));

  if (loading) {
    return (
      <div className="p-4 text-sm text-zinc-500">Loading solvers...</div>
    );
  }

  return (
    <div className="w-64 bg-zinc-900/95 border-l border-zinc-800 overflow-y-auto h-full">
      <div className="px-4 py-3 border-b border-zinc-800">
        <h3 className="text-sm font-semibold text-zinc-100">Solver palette</h3>
        <p className="text-xs text-zinc-500 mt-0.5">
          Drag onto agents or edges
        </p>
      </div>

      {Object.entries(grouped).map(([category, catSolvers]) => {
        const meta = CATEGORY_META[category] || {
          label: category,
          icon: <Cpu className="w-3.5 h-3.5" />,
          color: "#6366f1",
        };
        const isOpen = expanded[category] ?? false;

        return (
          <div key={category}>
            {/* Category header */}
            <button
              onClick={() => toggleCat(category)}
              className="w-full flex items-center gap-2 px-4 py-2.5 text-xs font-medium text-zinc-400 hover:bg-zinc-800/50 transition-colors"
            >
              {isOpen ? (
                <ChevronDown className="w-3 h-3" />
              ) : (
                <ChevronRight className="w-3 h-3" />
              )}
              <span style={{ color: meta.color }}>{meta.icon}</span>
              <span>{meta.label}</span>
              <span className="ml-auto text-zinc-600">{catSolvers.length}</span>
            </button>

            {/* Solver cards */}
            {isOpen &&
              catSolvers.map((solver) => (
                <div
                  key={solver.name}
                  draggable
                  onDragStart={(e) => {
                    e.dataTransfer.setData(
                      "application/digitwin-solver",
                      JSON.stringify(solver)
                    );
                    e.dataTransfer.effectAllowed = "copy";
                    onDragStart?.(solver);
                  }}
                  className="mx-3 mb-2 bg-zinc-800 rounded-lg px-3 py-2.5 cursor-grab active:cursor-grabbing hover:bg-zinc-750 border border-transparent hover:border-zinc-700 transition-all group"
                >
                  <div className="flex items-center gap-2">
                    <GripVertical className="w-3 h-3 text-zinc-600 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-zinc-200 truncate">
                        {solver.display_name}
                      </p>
                      <p className="text-[10px] text-zinc-500 mt-0.5 line-clamp-2">
                        {solver.description}
                      </p>
                    </div>
                  </div>

                  {/* Problem types pills */}
                  <div className="flex flex-wrap gap-1 mt-2">
                    {solver.supported_problem_types.slice(0, 3).map((pt) => (
                      <span
                        key={pt}
                        className="text-[9px] px-1.5 py-0.5 rounded bg-zinc-900 text-zinc-400"
                      >
                        {pt.replace(/_/g, " ")}
                      </span>
                    ))}
                    {solver.supported_problem_types.length > 3 && (
                      <span className="text-[9px] px-1.5 py-0.5 text-zinc-500">
                        +{solver.supported_problem_types.length - 3}
                      </span>
                    )}
                  </div>
                </div>
              ))}
          </div>
        );
      })}

      {solvers.length === 0 && (
        <div className="p-4 text-xs text-zinc-500 text-center">
          No solvers available
          {domain && ` for ${domain}`}
        </div>
      )}
    </div>
  );
}
