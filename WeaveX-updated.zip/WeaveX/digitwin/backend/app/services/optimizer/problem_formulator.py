"""
Problem formulator — the bridge between LLM reasoning and mathematical solvers.

When an agent hits a decision point that needs optimisation, this module:
1. Takes the current simulation state (who's waiting, what's available, etc.)
2. Asks the LLM to classify whether this needs a solver
3. If yes, asks the LLM to formulate the mathematical problem
4. Returns a ProblemSpec ready for the solver registry

This is the critical integration layer. The LLM is excellent at understanding
messy real-world context ("Dr. Chen is about to go off-shift, 3 patients are
ESI-2, bed 7 just opened up") and translating it into clean mathematical
structure ("minimise total wait, assign 3 patients to 1 bed, constraint:
ESI-2 patients must be seen within 10 minutes").
"""

import json
import structlog
from typing import Any

from ...utils.llm_client import OllamaClient
from .base import ProblemSpec, DecisionVariable, Constraint, ObjectiveFunction, VariableType

logger = structlog.get_logger()


class ProblemFormulator:
    """
    LLM-powered translation from simulation context to optimisation problems.

    Usage:
        formulator = ProblemFormulator()

        # Step 1: Should this interaction use a solver?
        needs_solver, problem_type = await formulator.classify(
            interaction_context={"type": "bed_assignment", ...},
            agent_tools=["lp_mip", "scheduling"],
        )

        # Step 2: If yes, formulate the problem
        if needs_solver:
            problem = await formulator.formulate(
                problem_type=problem_type,
                simulation_state=current_state,
                domain="healthcare",
            )
            # problem is now a ProblemSpec ready for the registry
    """

    def __init__(self, llm: OllamaClient | None = None):
        self.llm = llm or OllamaClient()

    async def classify(
        self,
        interaction_context: dict[str, Any],
        agent_tools: list[str],
    ) -> tuple[bool, str]:
        """
        Classify whether an interaction needs a solver or just LLM reasoning.

        Returns:
            (needs_solver: bool, problem_type: str)
            problem_type is empty string if needs_solver is False.
        """
        messages = [
            {
                "role": "system",
                "content": """You classify whether an agent interaction needs a mathematical
optimisation solver or can be handled by simple reasoning.

An interaction NEEDS a solver when:
- There are multiple items to assign/allocate (patients→beds, orders→vehicles)
- There's a scheduling problem (shifts, appointments, sequences)
- There's routing involved (delivery routes, patient pathways)
- There's a negotiation with payoffs (supplier contracts, pricing)
- There's uncertainty that affects the decision (demand forecasting, safety stock)

An interaction does NOT need a solver when:
- It's a simple communication (informing, updating status)
- It's a single yes/no or A-or-B decision
- It's recording or logging information
- It's a social interaction (greeting, discussing)

Respond with ONLY a JSON object:
{"needs_solver": true/false, "problem_type": "bed_assignment", "reason": "3 patients competing for 1 bed"}

Valid problem_types: bed_assignment, staff_allocation, shift_scheduling,
or_scheduling, task_scheduling, vehicle_routing, delivery_scheduling,
procurement_allocation, inventory_planning, safety_stock_optimization,
supplier_negotiation, competitive_pricing, resource_allocation,
vehicle_loading, capacity_planning, resource_bidding, cost_allocation"""
            },
            {
                "role": "user",
                "content": f"""Interaction context:
{json.dumps(interaction_context, indent=2)}

Available solver tools on this agent: {agent_tools}

Should this interaction use an optimisation solver?"""
            },
        ]

        result = await self.llm.chat_json(messages, temperature=0.1, max_tokens=256)

        needs_solver = result.get("needs_solver", False)
        problem_type = result.get("problem_type", "")

        logger.debug(
            "Classified interaction",
            needs_solver=needs_solver,
            problem_type=problem_type,
            reason=result.get("reason", ""),
        )

        return needs_solver, problem_type

    async def formulate(
        self,
        problem_type: str,
        simulation_state: dict[str, Any],
        domain: str = "",
        solver_hint: str = "",
    ) -> ProblemSpec:
        """
        Formulate a mathematical problem from simulation state.

        The LLM reads the current state and produces a structured ProblemSpec
        that the solver registry can dispatch to the right solver.
        """
        # Use domain-specific prompt templates
        template = DOMAIN_TEMPLATES.get(domain, {}).get(problem_type)
        if template:
            return await self._formulate_with_template(
                template, problem_type, simulation_state, domain
            )

        # Generic formulation
        return await self._formulate_generic(
            problem_type, simulation_state, domain
        )

    async def _formulate_with_template(
        self,
        template: dict,
        problem_type: str,
        state: dict[str, Any],
        domain: str,
    ) -> ProblemSpec:
        """Formulate using a domain-specific template + LLM to fill parameters."""
        messages = [
            {
                "role": "system",
                "content": f"""You are formulating a {problem_type} optimisation problem
for a {domain} digital twin simulation.

Template structure:
{json.dumps(template, indent=2)}

Given the current simulation state, fill in the specific values for
variables, constraints, and objectives. Respond with ONLY a JSON object
matching the ProblemSpec schema.

CRITICAL: Use concrete numbers from the state, not placeholders."""
            },
            {
                "role": "user",
                "content": f"""Current simulation state:
{json.dumps(state, indent=2)}

Formulate the {problem_type} problem with specific values."""
            },
        ]

        result = await self.llm.chat_json(messages, temperature=0.1, max_tokens=4096)
        return self._parse_problem_spec(result, problem_type, domain, state)

    async def _formulate_generic(
        self,
        problem_type: str,
        state: dict[str, Any],
        domain: str,
    ) -> ProblemSpec:
        """Generic formulation when no template exists."""
        messages = [
            {
                "role": "system",
                "content": f"""You are formulating an optimisation problem from simulation state.

Problem type: {problem_type}
Domain: {domain}

Respond with ONLY a JSON object with these fields:
{{
    "problem_type": "{problem_type}",
    "domain": "{domain}",
    "description": "Clear description of what we're optimising",
    "variables": [
        {{"name": "assign_X_to_Y", "var_type": "binary", "lower_bound": 0, "upper_bound": 1, "description": "..."}}
    ],
    "constraints": [
        {{"name": "capacity", "expression": "sum of assignments <= capacity", "constraint_type": "<=", "rhs": 10, "description": "..."}}
    ],
    "objectives": [
        {{"name": "minimise_wait", "expression": "sum of wait times", "direction": "minimize"}}
    ],
    "graph": null,
    "tasks": null,
    "resources": null,
    "players": null,
    "scenarios": null
}}

Fill in whichever fields are relevant for {problem_type}. Use null for irrelevant fields.
Use CONCRETE numbers from the simulation state."""
            },
            {
                "role": "user",
                "content": f"""Simulation state:
{json.dumps(state, indent=2)}"""
            },
        ]

        result = await self.llm.chat_json(messages, temperature=0.2, max_tokens=4096)
        return self._parse_problem_spec(result, problem_type, domain, state)

    def _parse_problem_spec(
        self, raw: dict, problem_type: str, domain: str, state: dict
    ) -> ProblemSpec:
        """Parse LLM output into a validated ProblemSpec."""
        variables = [
            DecisionVariable(
                name=v.get("name", f"x_{i}"),
                var_type=VariableType(v.get("var_type", "continuous")),
                lower_bound=v.get("lower_bound"),
                upper_bound=v.get("upper_bound"),
                description=v.get("description", ""),
            )
            for i, v in enumerate(raw.get("variables", []))
        ]

        constraints = [
            Constraint(
                name=c.get("name", f"c_{i}"),
                expression=c.get("expression", ""),
                constraint_type=c.get("constraint_type", "<="),
                rhs=c.get("rhs", 0),
                description=c.get("description", ""),
            )
            for i, c in enumerate(raw.get("constraints", []))
        ]

        objectives = [
            ObjectiveFunction(
                name=o.get("name", "objective"),
                expression=o.get("expression", ""),
                direction=o.get("direction", "minimize"),
                weight=o.get("weight", 1.0),
            )
            for o in raw.get("objectives", [])
        ]

        return ProblemSpec(
            problem_type=problem_type,
            domain=domain,
            description=raw.get("description", ""),
            variables=variables,
            constraints=constraints,
            objectives=objectives,
            graph=raw.get("graph"),
            tasks=raw.get("tasks"),
            resources=raw.get("resources"),
            players=raw.get("players"),
            scenarios=raw.get("scenarios"),
            simulation_context=state,
        )

    async def interpret_result(
        self,
        problem: ProblemSpec,
        result: "SolverResult",
        agent_name: str,
    ) -> str:
        """
        Translate a solver result back into natural language agent actions.

        This is the reverse direction: math → narrative.
        The LLM reads the solution and produces a human-readable action
        description that fits the simulation narrative.
        """
        from .base import SolverResult  # avoid circular import

        messages = [
            {
                "role": "system",
                "content": f"""You are narrating the actions of '{agent_name}' in a simulation.
An optimisation solver just produced a result. Translate it into
a clear, natural-language description of what the agent DOES as a result.

Be specific and action-oriented. Example:
"Assigns Patient Martinez (ESI-2) to Bed 4 in the acute care area,
and routes Patient Lee (ESI-3) to Fast Track Room 2. Bed 7 held
in reserve for the incoming trauma case."

Keep it to 2-4 sentences. No technical optimisation jargon."""
            },
            {
                "role": "user",
                "content": f"""Problem: {problem.description}

Solver result:
- Status: {result.status.value}
- Objective value: {result.objective_value}
- Assignments: {json.dumps(result.assignments[:10])}
- Routes: {json.dumps(result.routes[:5])}
- Schedule: {json.dumps(result.schedule[:10])}
- Equilibrium: {json.dumps(result.equilibrium)}

Simulation context: {json.dumps(problem.simulation_context)}

What does {agent_name} do?"""
            },
        ]

        return await self.llm.chat(messages, temperature=0.3, max_tokens=256)


# ================================================================
# Domain-specific problem templates
# ================================================================

DOMAIN_TEMPLATES: dict[str, dict[str, dict]] = {
    "healthcare": {
        "bed_assignment": {
            "description": "Assign waiting patients to available beds",
            "variable_pattern": "assign_{patient_id}_to_{bed_id} (binary)",
            "typical_constraints": [
                "Each patient assigned to at most one bed",
                "Each bed holds at most one patient",
                "ESI-1/2 patients get critical care beds",
                "Isolation patients get isolation rooms",
            ],
            "typical_objectives": [
                "Minimise total weighted wait time (ESI level = weight)",
                "Maximise acuity-bed match quality",
            ],
        },
        "shift_scheduling": {
            "description": "Schedule staff across shifts meeting coverage requirements",
            "variable_pattern": "assign_{staff_id}_to_{shift} (binary)",
            "typical_constraints": [
                "Minimum nurses per shift by department",
                "Maximum consecutive hours per staff",
                "Required skill mix (RN, LPN, CNA)",
                "Staff availability and preferences",
            ],
            "typical_objectives": [
                "Minimise total overtime",
                "Maximise preference satisfaction",
                "Ensure minimum coverage ratios",
            ],
        },
        "or_scheduling": {
            "description": "Schedule surgeries in operating rooms",
            "variable_pattern": "tasks with durations, dependencies, resource requirements",
            "typical_constraints": [
                "OR room availability windows",
                "Surgeon availability",
                "Equipment availability",
                "Patient prep time between surgeries",
            ],
            "typical_objectives": [
                "Minimise makespan (finish all surgeries earliest)",
                "Maximise number of surgeries scheduled",
            ],
        },
    },
    "logistics": {
        "vehicle_routing": {
            "description": "Plan delivery routes for fleet",
            "variable_pattern": "graph with depot, nodes (customers), demands",
            "typical_constraints": [
                "Vehicle capacity limits",
                "Time windows per delivery",
                "Driver shift length",
                "Vehicle availability",
            ],
            "typical_objectives": [
                "Minimise total distance / fuel cost",
                "Minimise number of vehicles used",
                "Minimise latest delivery time",
            ],
        },
        "delivery_scheduling": {
            "description": "Schedule deliveries respecting time windows and priorities",
            "variable_pattern": "tasks (deliveries) with time windows, resources (vehicles)",
            "typical_constraints": [
                "Delivery time windows",
                "Vehicle capacity",
                "Priority deliveries first",
                "Driver break requirements",
            ],
            "typical_objectives": [
                "Minimise late deliveries",
                "Minimise total route time",
            ],
        },
    },
    "supply_chain": {
        "procurement_allocation": {
            "description": "Allocate purchase orders across suppliers",
            "variable_pattern": "order_{item}_from_{supplier} (continuous/integer)",
            "typical_constraints": [
                "Total demand must be met",
                "Supplier capacity limits",
                "Minimum order quantities (MOQ)",
                "Budget constraints",
                "Quality requirements",
            ],
            "typical_objectives": [
                "Minimise total cost (unit price + shipping + handling)",
                "Minimise lead time risk",
            ],
        },
        "inventory_planning": {
            "description": "Set order quantities and safety stock under demand uncertainty",
            "variable_pattern": "scenarios with demand distributions and probabilities",
            "typical_constraints": [
                "Storage capacity",
                "Budget for inventory holding",
                "Minimum service level target",
            ],
            "typical_objectives": [
                "Minimise expected total cost (ordering + holding + shortage)",
                "Maximise service level",
            ],
        },
        "supplier_negotiation": {
            "description": "Strategic negotiation between buyer and supplier",
            "variable_pattern": "players with strategies and payoff matrices",
            "typical_constraints": [
                "Buyer budget ceiling",
                "Supplier minimum margin",
                "Contract term requirements",
            ],
            "typical_objectives": [
                "Find Nash equilibrium pricing",
                "Maximise buyer payoff (Stackelberg if buyer leads)",
            ],
        },
    },
}
