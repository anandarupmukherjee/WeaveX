"""
Solver registry — discovers, registers, and dispatches to solver adapters.

The registry is the single entry point the agent runtime uses. It:
1. Holds all available solver adapters
2. Matches a ProblemSpec to the best solver (or user-assigned solver)
3. Dispatches the solve call
4. Returns the result

Canvas UI queries the registry for the solver palette (all available
solvers with their metadata, configurable params, and supported types).
"""

import structlog
from typing import Any

from .base import SolverAdapter, ProblemSpec, SolverResult, SolveStatus

# Import all P1 adapters
from .adapters.lp_mip import LPMIPAdapter
from .adapters.vrp import VRPAdapter
from .adapters.scheduling import SchedulingAdapter
from .adapters.game_theory import GameTheoryAdapter
from .adapters.stochastic import StochasticAdapter

logger = structlog.get_logger()


class SolverRegistry:
    """
    Central registry for all optimization solver adapters.

    Usage:
        registry = SolverRegistry()

        # Auto-dispatch (registry picks the best solver)
        result = await registry.solve(problem_spec)

        # Explicit solver (user assigned via canvas)
        result = await registry.solve(problem_spec, solver_name="vrp")

        # Get all solvers for the canvas palette
        palette = registry.get_palette()

        # Get solvers relevant to a domain
        solvers = registry.get_for_domain("healthcare")
    """

    def __init__(self):
        self._solvers: dict[str, SolverAdapter] = {}
        self._register_defaults()

    def _register_defaults(self):
        """Register all P1 solver adapters."""
        defaults = [
            LPMIPAdapter(),
            VRPAdapter(),
            SchedulingAdapter(),
            GameTheoryAdapter(),
            StochasticAdapter(),
        ]
        for solver in defaults:
            self.register(solver)

    def register(self, solver: SolverAdapter):
        """Register a solver adapter."""
        self._solvers[solver.name] = solver
        logger.debug("Registered solver", name=solver.name, types=solver.supported_problem_types)

    def get(self, name: str) -> SolverAdapter | None:
        """Get a solver by name."""
        return self._solvers.get(name)

    def list_solvers(self) -> list[str]:
        """List all registered solver names."""
        return list(self._solvers.keys())

    async def solve(
        self,
        problem: ProblemSpec,
        solver_name: str | None = None,
    ) -> SolverResult:
        """
        Solve a problem, either with a specific solver or auto-dispatched.

        Args:
            problem: The problem specification
            solver_name: Specific solver to use (from canvas assignment).
                         If None, auto-selects based on problem_type.

        Returns:
            SolverResult with the solution
        """
        # Pick solver
        if solver_name:
            solver = self._solvers.get(solver_name)
            if not solver:
                return SolverResult(
                    status=SolveStatus.ERROR,
                    explanation=f"Solver '{solver_name}' not found in registry",
                )
        else:
            solver = self._find_best_solver(problem)
            if not solver:
                return SolverResult(
                    status=SolveStatus.ERROR,
                    explanation=f"No solver found for problem type '{problem.problem_type}'",
                )

        logger.info(
            "Dispatching to solver",
            solver=solver.name,
            problem_type=problem.problem_type,
            domain=problem.domain,
        )

        result = await solver.solve(problem)

        logger.info(
            "Solver complete",
            solver=solver.name,
            status=result.status.value,
            solve_time=f"{result.solve_time_seconds:.2f}s",
            objective=result.objective_value,
        )

        return result

    def _find_best_solver(self, problem: ProblemSpec) -> SolverAdapter | None:
        """Auto-select the best solver for a problem based on type and domain."""
        candidates = [
            s for s in self._solvers.values()
            if s.can_handle(problem)
        ]

        if not candidates:
            return None

        # Prefer domain-matched solvers
        if problem.domain:
            domain_matched = [
                s for s in candidates
                if problem.domain in s.supported_domains
            ]
            if domain_matched:
                candidates = domain_matched

        # Return first match (could rank by priority later)
        return candidates[0]

    def get_palette(self) -> list[dict[str, Any]]:
        """
        Return solver metadata for the canvas solver palette UI.

        The frontend renders this as a draggable palette of solver cards
        that users can drop onto agent nodes or interaction edges.
        """
        return [
            solver.metadata() for solver in self._solvers.values()
        ]

    def get_for_domain(self, domain: str) -> list[dict[str, Any]]:
        """Get solvers relevant to a specific domain."""
        return [
            solver.metadata()
            for solver in self._solvers.values()
            if domain in solver.supported_domains
        ]

    def get_for_problem_type(self, problem_type: str) -> list[dict[str, Any]]:
        """Get solvers that can handle a specific problem type."""
        return [
            solver.metadata()
            for solver in self._solvers.values()
            if problem_type in solver.supported_problem_types
        ]


# Global singleton
_registry: SolverRegistry | None = None


def get_registry() -> SolverRegistry:
    """Get or create the global solver registry."""
    global _registry
    if _registry is None:
        _registry = SolverRegistry()
    return _registry
