"""
Optimisation toolbox — base classes.

Every solver in the toolbox, regardless of method (LP, GA, Nash, RL...),
implements the same SolverAdapter interface. This lets the agent runtime,
the problem formulator, and the canvas UI treat all solvers uniformly.

The flow:
    SimulationState → ProblemFormulator → ProblemSpec → SolverAdapter → SolverResult
                                                            ↑
                                              SolverRegistry picks the right one
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ============================================================
# Problem specification — what gets sent TO the solver
# ============================================================

class VariableType(str, Enum):
    CONTINUOUS = "continuous"
    INTEGER = "integer"
    BINARY = "binary"


class DecisionVariable(BaseModel):
    """A single decision variable in the optimisation problem."""
    name: str
    var_type: VariableType = VariableType.CONTINUOUS
    lower_bound: float | None = None
    upper_bound: float | None = None
    description: str = ""


class Constraint(BaseModel):
    """A constraint on the decision variables."""
    name: str
    expression: str = Field(description="Human-readable or symbolic expression")
    constraint_type: str = Field(default="<=", description="<=, >=, ==")
    rhs: float = 0.0
    description: str = ""


class ObjectiveFunction(BaseModel):
    """What to optimise."""
    name: str
    expression: str = Field(description="Human-readable or symbolic expression")
    direction: str = Field(default="minimize", description="minimize or maximize")
    weight: float = Field(default=1.0, description="Weight in multi-objective")


class ProblemSpec(BaseModel):
    """
    Universal problem specification sent to any solver.

    This is the contract between the ProblemFormulator (LLM-powered) and
    the SolverAdapter. The formulator fills this from simulation context;
    the adapter translates it into solver-specific input.

    For different solver types, different fields are primary:
    - LP/MIP: variables, constraints, objectives (standard form)
    - VRP/TSP: graph (nodes, edges, demands)
    - Scheduling: tasks, resources, time_windows
    - Game theory: players, strategies, payoffs
    - Stochastic: scenarios, probabilities
    """
    # Problem metadata
    problem_type: str = Field(description="bed_assignment, vehicle_routing, shift_scheduling, ...")
    domain: str = Field(default="", description="healthcare, logistics, supply_chain")
    description: str = ""

    # Standard optimisation fields
    variables: list[DecisionVariable] = Field(default_factory=list)
    constraints: list[Constraint] = Field(default_factory=list)
    objectives: list[ObjectiveFunction] = Field(default_factory=list)

    # Graph / network fields (for routing, flow problems)
    graph: dict[str, Any] | None = Field(
        default=None,
        description="Nodes, edges, capacities, demands for graph problems",
    )

    # Scheduling fields
    tasks: list[dict[str, Any]] | None = Field(
        default=None,
        description="Tasks with durations, dependencies, resource requirements",
    )
    resources: list[dict[str, Any]] | None = Field(
        default=None,
        description="Available resources with capacities and availability windows",
    )

    # Game theory fields
    players: list[dict[str, Any]] | None = Field(
        default=None,
        description="Players with strategies and payoff functions",
    )

    # Stochastic fields
    scenarios: list[dict[str, Any]] | None = Field(
        default=None,
        description="Scenarios with probabilities for stochastic programming",
    )

    # Solver config (overridable from canvas UI)
    time_limit_seconds: float = 30.0
    gap_tolerance: float = 0.01  # MIP gap
    solver_params: dict[str, Any] = Field(default_factory=dict)

    # Context from simulation (passed through for result interpretation)
    simulation_context: dict[str, Any] = Field(
        default_factory=dict,
        description="Raw simulation state for the LLM to interpret results",
    )


# ============================================================
# Solver result — what comes BACK from the solver
# ============================================================

class SolveStatus(str, Enum):
    OPTIMAL = "optimal"
    FEASIBLE = "feasible"       # Solution found but not proven optimal
    INFEASIBLE = "infeasible"   # No solution satisfies all constraints
    UNBOUNDED = "unbounded"
    TIME_LIMIT = "time_limit"   # Stopped by time limit, best found returned
    ERROR = "error"


class SolverResult(BaseModel):
    """
    Universal result from any solver.

    The agent runtime / LLM reads this to determine what action to take.
    """
    status: SolveStatus
    objective_value: float | None = None

    # Variable assignments (the solution)
    solution: dict[str, float] = Field(
        default_factory=dict,
        description="Variable name → value mapping",
    )

    # Structured solution for complex problems
    assignments: list[dict[str, Any]] = Field(
        default_factory=list,
        description="For assignment/scheduling: list of who→what mappings",
    )
    routes: list[list[str]] = Field(
        default_factory=list,
        description="For routing: ordered lists of stops per vehicle",
    )
    schedule: list[dict[str, Any]] = Field(
        default_factory=list,
        description="For scheduling: task→time→resource mappings",
    )
    equilibrium: dict[str, Any] | None = Field(
        default=None,
        description="For game theory: Nash equilibrium strategies",
    )

    # Metadata
    solve_time_seconds: float = 0.0
    solver_name: str = ""
    gap: float | None = None  # MIP gap if applicable

    # Human-readable summary (generated by LLM after solving)
    explanation: str = ""


# ============================================================
# Solver adapter — base class all solvers implement
# ============================================================

class SolverCategory(str, Enum):
    CLASSICAL = "classical"
    COMBINATORIAL = "combinatorial"
    GAME_THEORY = "game_theory"
    STOCHASTIC = "stochastic"
    EVOLUTIONARY = "evolutionary"
    RL = "reinforcement_learning"
    BAYESIAN = "bayesian"
    DYNAMIC = "dynamic_programming"
    NEURAL = "neural"


class SolverAdapter(ABC):
    """
    Base class for all solver adapters.

    Every solver in the toolbox subclasses this and implements:
    - solve(): the actual solving logic
    - can_handle(): whether this solver is appropriate for a given problem
    - configurable_params(): what parameters the canvas UI can expose as sliders
    """

    # Metadata — subclasses set these
    name: str = "base_solver"
    display_name: str = "Base solver"
    category: SolverCategory = SolverCategory.CLASSICAL
    description: str = ""
    supported_problem_types: list[str] = []
    supported_domains: list[str] = ["healthcare", "logistics", "supply_chain"]

    def can_handle(self, problem: ProblemSpec) -> bool:
        """Check if this solver can handle the given problem."""
        return problem.problem_type in self.supported_problem_types

    @abstractmethod
    async def solve(self, problem: ProblemSpec) -> SolverResult:
        """
        Solve the problem and return a result.

        Implementations should:
        1. Translate ProblemSpec into solver-specific format
        2. Run the solver
        3. Translate the output back into SolverResult
        4. Handle errors gracefully (return SolveStatus.ERROR, not raise)
        """
        ...

    def configurable_params(self) -> list[dict[str, Any]]:
        """
        Parameters the canvas UI can expose as sliders/inputs.

        Returns a list of parameter definitions:
        [
            {"name": "time_limit", "type": "float", "min": 1, "max": 300, "default": 30, "label": "Time limit (s)"},
            {"name": "gap_tolerance", "type": "float", "min": 0.001, "max": 0.1, "default": 0.01, "label": "MIP gap"},
        ]
        """
        return [
            {
                "name": "time_limit_seconds",
                "type": "float",
                "min": 1.0,
                "max": 300.0,
                "default": 30.0,
                "label": "Time limit (seconds)",
            }
        ]

    def metadata(self) -> dict[str, Any]:
        """Return solver metadata for the canvas solver palette."""
        return {
            "name": self.name,
            "display_name": self.display_name,
            "category": self.category.value,
            "description": self.description,
            "supported_problem_types": self.supported_problem_types,
            "supported_domains": self.supported_domains,
            "configurable_params": self.configurable_params(),
        }
