"""
Stochastic programming solver adapter.

Handles: inventory under demand uncertainty, capacity planning with
uncertain supply, risk-adjusted procurement, scenario-based planning.

Uses sample average approximation (SAA) with scipy for the inner LP.
"""

import time
import numpy as np
from typing import Any
from scipy.optimize import linprog

from ..base import (
    SolverAdapter, SolverCategory, SolverResult, SolveStatus, ProblemSpec,
)


class StochasticAdapter(SolverAdapter):
    """
    Stochastic programming via sample average approximation.

    Expects problem.scenarios:
    [
        {
            "id": "high_demand",
            "probability": 0.3,
            "params": {"demand": 500, "lead_time": 14}
        },
        {
            "id": "normal_demand",
            "probability": 0.5,
            "params": {"demand": 300, "lead_time": 7}
        },
        {
            "id": "low_demand",
            "probability": 0.2,
            "params": {"demand": 150, "lead_time": 5}
        }
    ]

    And problem.variables for the here-and-now decisions (e.g., order quantity,
    safety stock level) that must be decided BEFORE the scenario is revealed.
    """

    name = "stochastic"
    display_name = "Stochastic programming (SAA)"
    category = SolverCategory.STOCHASTIC
    description = "Decisions under uncertainty with scenario analysis"
    supported_problem_types = [
        "inventory_planning",
        "capacity_planning",
        "risk_adjusted_procurement",
        "safety_stock_optimization",
        "scenario_planning",
    ]
    supported_domains = ["supply_chain", "logistics", "healthcare"]

    def configurable_params(self) -> list[dict[str, Any]]:
        return [
            {"name": "time_limit_seconds", "type": "float", "min": 5, "max": 120, "default": 30, "label": "Time limit (s)"},
            {"name": "risk_aversion", "type": "float", "min": 0.0, "max": 1.0, "default": 0.5, "label": "Risk aversion (0=neutral, 1=worst-case)"},
            {"name": "num_samples", "type": "int", "min": 100, "max": 10000, "default": 1000, "label": "Monte Carlo samples"},
        ]

    async def solve(self, problem: ProblemSpec) -> SolverResult:
        start = time.time()

        scenarios = problem.scenarios or []
        if not scenarios:
            return SolverResult(
                status=SolveStatus.ERROR,
                solver_name=self.name,
                explanation="No scenarios provided for stochastic problem",
            )

        try:
            result = self._solve_saa(problem, scenarios)
        except Exception as e:
            return SolverResult(
                status=SolveStatus.ERROR,
                solver_name=self.name,
                solve_time_seconds=time.time() - start,
                explanation=f"Stochastic solver error: {str(e)}",
            )

        result.solve_time_seconds = time.time() - start
        result.solver_name = self.name
        return result

    def _solve_saa(
        self, problem: ProblemSpec, scenarios: list[dict]
    ) -> SolverResult:
        """
        Sample average approximation.

        For inventory/safety stock problems, the structure is:
        - Decision: order quantity Q (here-and-now)
        - Scenarios: demand D_s with probability p_s
        - Cost: ordering_cost * Q + E[shortage_cost * max(0, D_s - Q) + holding_cost * max(0, Q - D_s)]

        We evaluate each candidate Q across all scenarios and pick the best.
        """
        risk_aversion = problem.solver_params.get("risk_aversion", 0.5)
        num_samples = problem.solver_params.get("num_samples", 1000)

        # Extract scenario parameters
        probabilities = np.array([s.get("probability", 1.0 / len(scenarios)) for s in scenarios])
        probabilities /= probabilities.sum()  # normalise

        # Get cost parameters from problem context or defaults
        ctx = problem.simulation_context
        ordering_cost = ctx.get("ordering_cost", 1.0)
        holding_cost = ctx.get("holding_cost", 0.5)
        shortage_cost = ctx.get("shortage_cost", 5.0)

        # Extract demand values from scenarios
        demands = np.array([s.get("params", {}).get("demand", 100) for s in scenarios])

        # Generate Monte Carlo samples from scenario distribution
        scenario_indices = np.random.choice(
            len(scenarios), size=num_samples, p=probabilities
        )
        sampled_demands = demands[scenario_indices]

        # Search over candidate order quantities
        q_min = float(demands.min() * 0.5)
        q_max = float(demands.max() * 1.5)
        candidates = np.linspace(q_min, q_max, 200)

        best_q = q_min
        best_cost = float("inf")
        scenario_costs = {}

        for q in candidates:
            shortages = np.maximum(0, sampled_demands - q)
            holdings = np.maximum(0, q - sampled_demands)
            total_costs = ordering_cost * q + shortage_cost * shortages + holding_cost * holdings

            # Risk-adjusted objective: (1-α) * E[cost] + α * CVaR
            expected_cost = float(np.mean(total_costs))

            if risk_aversion > 0:
                # CVaR at 95% level
                sorted_costs = np.sort(total_costs)
                cvar_idx = int(0.95 * num_samples)
                cvar = float(np.mean(sorted_costs[cvar_idx:]))
                obj = (1 - risk_aversion) * expected_cost + risk_aversion * cvar
            else:
                obj = expected_cost

            if obj < best_cost:
                best_cost = obj
                best_q = float(q)

        # Evaluate best Q against each named scenario
        for s in scenarios:
            d = s.get("params", {}).get("demand", 100)
            shortage = max(0, d - best_q)
            holding = max(0, best_q - d)
            cost = ordering_cost * best_q + shortage_cost * shortage + holding_cost * holding
            scenario_costs[s.get("id", "unknown")] = {
                "demand": d,
                "shortage": shortage,
                "holding": holding,
                "total_cost": round(cost, 2),
                "service_level": round(min(best_q / d, 1.0) * 100, 1) if d > 0 else 100,
            }

        # Service level (% of demand met)
        avg_service = float(np.mean(np.minimum(best_q / sampled_demands, 1.0))) * 100

        return SolverResult(
            status=SolveStatus.OPTIMAL,
            objective_value=round(best_cost, 2),
            solution={
                "optimal_order_quantity": round(best_q, 1),
                "expected_cost": round(float(np.mean(
                    ordering_cost * best_q
                    + shortage_cost * np.maximum(0, sampled_demands - best_q)
                    + holding_cost * np.maximum(0, best_q - sampled_demands)
                )), 2),
                "avg_service_level_pct": round(avg_service, 1),
                "risk_aversion": risk_aversion,
            },
            assignments=[
                {"scenario": sid, **details}
                for sid, details in scenario_costs.items()
            ],
        )
