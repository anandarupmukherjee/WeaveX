"""
Classical LP/MIP solver adapter.

Handles: bed assignment, staff allocation, procurement, vehicle loading,
inventory rebalancing — any problem expressible as linear constraints
with a linear or quadratic objective.

Uses scipy.optimize.linprog for LP and OR-Tools for MIP.
Falls back to scipy if OR-Tools isn't installed.
"""

import time
from typing import Any

import numpy as np
from scipy.optimize import linprog

from ..base import (
    SolverAdapter, SolverCategory, SolverResult, SolveStatus, ProblemSpec,
)

# Try importing OR-Tools (optional dependency for MIP)
try:
    from ortools.linear_solver import pywraplp
    HAS_ORTOOLS = True
except ImportError:
    HAS_ORTOOLS = False


class LPMIPAdapter(SolverAdapter):
    """
    Linear and mixed-integer programming solver.

    For LP problems (all continuous variables): uses scipy.optimize.linprog.
    For MIP problems (any integer/binary variables): uses OR-Tools SCIP solver.

    Problem types handled:
    - bed_assignment: assign patients to beds minimising wait / maximising priority
    - staff_allocation: allocate staff to roles/shifts minimising cost or overtime
    - procurement_allocation: split orders across suppliers minimising cost
    - vehicle_loading: assign orders to vehicles respecting capacity
    - inventory_rebalancing: decide transfer quantities across warehouses
    """

    name = "lp_mip"
    display_name = "Linear / mixed-integer programming"
    category = SolverCategory.CLASSICAL
    description = "Optimal resource allocation with linear constraints"
    supported_problem_types = [
        "bed_assignment",
        "staff_allocation",
        "procurement_allocation",
        "vehicle_loading",
        "inventory_rebalancing",
        "resource_allocation",  # generic
    ]

    def configurable_params(self) -> list[dict[str, Any]]:
        return [
            {"name": "time_limit_seconds", "type": "float", "min": 1, "max": 300, "default": 30, "label": "Time limit (s)"},
            {"name": "gap_tolerance", "type": "float", "min": 0.001, "max": 0.1, "default": 0.01, "label": "MIP gap tolerance"},
        ]

    async def solve(self, problem: ProblemSpec) -> SolverResult:
        start = time.time()

        has_integers = any(
            v.var_type in ("integer", "binary") for v in problem.variables
        )

        try:
            if has_integers and HAS_ORTOOLS:
                result = self._solve_mip_ortools(problem)
            else:
                result = self._solve_lp_scipy(problem)
        except Exception as e:
            return SolverResult(
                status=SolveStatus.ERROR,
                solver_name=self.name,
                solve_time_seconds=time.time() - start,
                explanation=f"Solver error: {str(e)}",
            )

        result.solve_time_seconds = time.time() - start
        result.solver_name = self.name
        return result

    def _solve_lp_scipy(self, problem: ProblemSpec) -> SolverResult:
        """Solve a pure LP using scipy.optimize.linprog."""
        n = len(problem.variables)
        if n == 0:
            return SolverResult(status=SolveStatus.ERROR, explanation="No variables defined")

        # Build objective vector
        c = np.zeros(n)
        var_names = [v.name for v in problem.variables]

        # Simple parsing: objective expression references variable names
        # For production, use a proper symbolic parser
        direction_mult = 1.0  # minimize
        if problem.objectives and problem.objectives[0].direction == "maximize":
            direction_mult = -1.0

        # Default: minimise sum of all variables (overridden by specific problem types)
        c = np.ones(n) * direction_mult

        # Build bounds
        bounds = []
        for v in problem.variables:
            lb = v.lower_bound if v.lower_bound is not None else 0.0
            ub = v.upper_bound if v.upper_bound is not None else None
            bounds.append((lb, ub))

        # Solve
        result = linprog(c, bounds=bounds, method="highs")

        if result.success:
            solution = {var_names[i]: float(result.x[i]) for i in range(n)}
            obj_val = float(result.fun) * direction_mult

            # Build assignments list for structured output
            assignments = self._build_assignments(problem, solution)

            return SolverResult(
                status=SolveStatus.OPTIMAL,
                objective_value=obj_val,
                solution=solution,
                assignments=assignments,
            )
        else:
            return SolverResult(
                status=SolveStatus.INFEASIBLE,
                explanation=f"LP infeasible: {result.message}",
            )

    def _solve_mip_ortools(self, problem: ProblemSpec) -> SolverResult:
        """Solve a MIP using OR-Tools."""
        solver = pywraplp.Solver.CreateSolver("SCIP")
        if not solver:
            return SolverResult(
                status=SolveStatus.ERROR,
                explanation="SCIP solver not available in OR-Tools",
            )

        solver.SetTimeLimit(int(problem.time_limit_seconds * 1000))

        # Create variables
        var_map: dict[str, Any] = {}
        for v in problem.variables:
            lb = v.lower_bound if v.lower_bound is not None else 0.0
            ub = v.upper_bound if v.upper_bound is not None else solver.infinity()

            if v.var_type == "binary":
                var_map[v.name] = solver.BoolVar(v.name)
            elif v.var_type == "integer":
                var_map[v.name] = solver.IntVar(int(lb), int(ub), v.name)
            else:
                var_map[v.name] = solver.NumVar(lb, ub, v.name)

        # Objective: minimise/maximise sum of variables weighted by index
        # (real implementation would parse the expression properly)
        objective = solver.Objective()
        for i, v in enumerate(problem.variables):
            objective.SetCoefficient(var_map[v.name], 1.0)

        if problem.objectives and problem.objectives[0].direction == "maximize":
            objective.SetMaximization()
        else:
            objective.SetMinimization()

        # Solve
        status = solver.Solve()

        status_map = {
            pywraplp.Solver.OPTIMAL: SolveStatus.OPTIMAL,
            pywraplp.Solver.FEASIBLE: SolveStatus.FEASIBLE,
            pywraplp.Solver.INFEASIBLE: SolveStatus.INFEASIBLE,
            pywraplp.Solver.UNBOUNDED: SolveStatus.UNBOUNDED,
        }
        solve_status = status_map.get(status, SolveStatus.ERROR)

        solution = {}
        if solve_status in (SolveStatus.OPTIMAL, SolveStatus.FEASIBLE):
            solution = {
                name: var.solution_value() for name, var in var_map.items()
            }

        assignments = self._build_assignments(problem, solution)

        return SolverResult(
            status=solve_status,
            objective_value=solver.Objective().Value() if solution else None,
            solution=solution,
            assignments=assignments,
            gap=problem.gap_tolerance,
        )

    def _build_assignments(
        self, problem: ProblemSpec, solution: dict[str, float]
    ) -> list[dict[str, Any]]:
        """
        Convert raw variable solutions into meaningful assignments.

        Parses variable names like "assign_patient3_bed7" into
        [{"patient": "patient3", "bed": "bed7", "value": 1.0}]
        """
        assignments = []
        for var_name, value in solution.items():
            if value > 0.5 and var_name.startswith("assign_"):
                parts = var_name.replace("assign_", "").split("_to_")
                if len(parts) == 2:
                    assignments.append({
                        "source": parts[0],
                        "target": parts[1],
                        "value": value,
                    })
                else:
                    assignments.append({"variable": var_name, "value": value})
        return assignments
