"""
Game theory solver adapter.

Handles: supplier negotiation, competitive pricing, resource bidding,
cost allocation between departments.

Uses nashpy for Nash equilibrium computation and custom implementations
for Stackelberg games.
"""

import time
import numpy as np
from typing import Any

from ..base import (
    SolverAdapter, SolverCategory, SolverResult, SolveStatus, ProblemSpec,
)

try:
    import nashpy as nash
    HAS_NASHPY = True
except ImportError:
    HAS_NASHPY = False


class GameTheoryAdapter(SolverAdapter):
    """
    Game theory solver for multi-agent strategic interactions.

    Expects problem.players:
    {
        "players": [
            {
                "id": "supplier_a",
                "strategies": ["low_price", "mid_price", "high_price"],
            },
            {
                "id": "buyer",
                "strategies": ["accept", "negotiate", "reject"],
            }
        ],
        "payoff_matrix_row": [     # row player (player 0) payoffs
            [3, 5, 1],             # supplier: low_price vs buyer's 3 strategies
            [6, 4, 2],             # supplier: mid_price
            [8, 3, 0],             # supplier: high_price
        ],
        "payoff_matrix_col": [     # column player (player 1) payoffs
            [7, 2, 5],
            [4, 6, 4],
            [1, 5, 8],
        ],
        "game_type": "nash" | "stackelberg" | "shapley"
    }
    """

    name = "game_theory"
    display_name = "Game theory (Nash, Stackelberg)"
    category = SolverCategory.GAME_THEORY
    description = "Strategic interactions: negotiation, pricing, auctions"
    supported_problem_types = [
        "supplier_negotiation",
        "competitive_pricing",
        "resource_bidding",
        "cost_allocation",
        "contract_negotiation",
    ]
    supported_domains = ["supply_chain", "logistics", "healthcare"]

    def configurable_params(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "game_type",
                "type": "select",
                "options": ["nash", "stackelberg", "maximin"],
                "default": "nash",
                "label": "Solution concept",
            },
        ]

    async def solve(self, problem: ProblemSpec) -> SolverResult:
        start = time.time()

        if not problem.players or len(problem.players) < 2:
            return SolverResult(
                status=SolveStatus.ERROR,
                solver_name=self.name,
                explanation="Need at least 2 players for game theory",
            )

        game_type = problem.solver_params.get("game_type", "nash")

        try:
            if game_type == "stackelberg":
                result = self._solve_stackelberg(problem)
            elif game_type == "maximin":
                result = self._solve_maximin(problem)
            else:
                result = self._solve_nash(problem)
        except Exception as e:
            return SolverResult(
                status=SolveStatus.ERROR,
                solver_name=self.name,
                solve_time_seconds=time.time() - start,
                explanation=f"Game theory error: {str(e)}",
            )

        result.solve_time_seconds = time.time() - start
        result.solver_name = self.name
        return result

    def _solve_nash(self, problem: ProblemSpec) -> SolverResult:
        """Find Nash equilibria using nashpy or brute force."""
        players = problem.players
        p0 = players[0]
        p1 = players[1]

        # Extract payoff matrices from players data
        payoff_row = np.array(p0.get("payoffs", [[0]]))
        payoff_col = np.array(p1.get("payoffs", [[0]]))

        strategies_0 = p0.get("strategies", [f"s{i}" for i in range(payoff_row.shape[0])])
        strategies_1 = p1.get("strategies", [f"s{i}" for i in range(payoff_col.shape[1])])

        if HAS_NASHPY:
            game = nash.Game(payoff_row, payoff_col)
            equilibria = list(game.support_enumeration())

            if not equilibria:
                # Try vertex enumeration as fallback
                try:
                    equilibria = list(game.vertex_enumeration())
                except Exception:
                    pass

            if equilibria:
                # Pick the first equilibrium
                eq = equilibria[0]
                mixed_0 = eq[0].tolist()
                mixed_1 = eq[1].tolist()

                # Expected payoffs
                exp_payoff_0 = float(eq[0] @ payoff_row @ eq[1])
                exp_payoff_1 = float(eq[0] @ payoff_col @ eq[1])

                return SolverResult(
                    status=SolveStatus.OPTIMAL,
                    objective_value=exp_payoff_0,
                    equilibrium={
                        "type": "nash",
                        "num_equilibria_found": len(equilibria),
                        "players": {
                            p0["id"]: {
                                "mixed_strategy": dict(zip(strategies_0, mixed_0)),
                                "expected_payoff": exp_payoff_0,
                            },
                            p1["id"]: {
                                "mixed_strategy": dict(zip(strategies_1, mixed_1)),
                                "expected_payoff": exp_payoff_1,
                            },
                        },
                    },
                    solution={
                        f"{p0['id']}_strategy": mixed_0,
                        f"{p1['id']}_strategy": mixed_1,
                        f"{p0['id']}_payoff": exp_payoff_0,
                        f"{p1['id']}_payoff": exp_payoff_1,
                    },
                )

        # Fallback: find pure strategy Nash equilibria
        return self._find_pure_nash(
            payoff_row, payoff_col, strategies_0, strategies_1, players
        )

    def _find_pure_nash(
        self,
        payoff_row: np.ndarray,
        payoff_col: np.ndarray,
        strats_0: list[str],
        strats_1: list[str],
        players: list[dict],
    ) -> SolverResult:
        """Find pure strategy Nash equilibria by checking best responses."""
        m, n = payoff_row.shape
        equilibria = []

        for i in range(m):
            for j in range(n):
                # Check if i is best response to j
                is_br_0 = payoff_row[i, j] >= max(payoff_row[k, j] for k in range(m))
                # Check if j is best response to i
                is_br_1 = payoff_col[i, j] >= max(payoff_col[i, k] for k in range(n))

                if is_br_0 and is_br_1:
                    equilibria.append((i, j))

        if equilibria:
            i, j = equilibria[0]
            return SolverResult(
                status=SolveStatus.OPTIMAL,
                objective_value=float(payoff_row[i, j]),
                equilibrium={
                    "type": "pure_nash",
                    "num_equilibria_found": len(equilibria),
                    "players": {
                        players[0]["id"]: {
                            "strategy": strats_0[i],
                            "payoff": float(payoff_row[i, j]),
                        },
                        players[1]["id"]: {
                            "strategy": strats_1[j],
                            "payoff": float(payoff_col[i, j]),
                        },
                    },
                },
            )

        return SolverResult(
            status=SolveStatus.FEASIBLE,
            explanation="No pure strategy Nash equilibrium found; install nashpy for mixed strategies",
        )

    def _solve_stackelberg(self, problem: ProblemSpec) -> SolverResult:
        """
        Stackelberg equilibrium: player 0 is the leader, player 1 is the follower.
        Leader commits to a strategy first, follower best-responds.
        """
        players = problem.players
        payoff_row = np.array(players[0].get("payoffs", [[0]]))
        payoff_col = np.array(players[1].get("payoffs", [[0]]))
        m, n = payoff_row.shape

        strats_0 = players[0].get("strategies", [f"s{i}" for i in range(m)])
        strats_1 = players[1].get("strategies", [f"s{i}" for i in range(n)])

        best_leader_payoff = float("-inf")
        best_i = 0
        best_j = 0

        for i in range(m):
            # Follower best-responds to leader's choice i
            j = int(np.argmax(payoff_col[i, :]))
            leader_payoff = payoff_row[i, j]

            if leader_payoff > best_leader_payoff:
                best_leader_payoff = leader_payoff
                best_i = i
                best_j = j

        return SolverResult(
            status=SolveStatus.OPTIMAL,
            objective_value=float(best_leader_payoff),
            equilibrium={
                "type": "stackelberg",
                "leader": {
                    "id": players[0]["id"],
                    "strategy": strats_0[best_i],
                    "payoff": float(payoff_row[best_i, best_j]),
                },
                "follower": {
                    "id": players[1]["id"],
                    "best_response": strats_1[best_j],
                    "payoff": float(payoff_col[best_i, best_j]),
                },
            },
        )

    def _solve_maximin(self, problem: ProblemSpec) -> SolverResult:
        """Maximin: each player maximises their minimum payoff (conservative)."""
        players = problem.players
        payoff_row = np.array(players[0].get("payoffs", [[0]]))
        payoff_col = np.array(players[1].get("payoffs", [[0]]))

        strats_0 = players[0].get("strategies", [f"s{i}" for i in range(payoff_row.shape[0])])
        strats_1 = players[1].get("strategies", [f"s{i}" for i in range(payoff_col.shape[1])])

        # Player 0: max over rows of min over columns
        row_mins = payoff_row.min(axis=1)
        i = int(np.argmax(row_mins))

        # Player 1: max over columns of min over rows
        col_mins = payoff_col.min(axis=0)
        j = int(np.argmax(col_mins))

        return SolverResult(
            status=SolveStatus.OPTIMAL,
            objective_value=float(payoff_row[i, j]),
            equilibrium={
                "type": "maximin",
                "players": {
                    players[0]["id"]: {
                        "strategy": strats_0[i],
                        "guaranteed_payoff": float(row_mins[i]),
                    },
                    players[1]["id"]: {
                        "strategy": strats_1[j],
                        "guaranteed_payoff": float(col_mins[j]),
                    },
                },
            },
        )
