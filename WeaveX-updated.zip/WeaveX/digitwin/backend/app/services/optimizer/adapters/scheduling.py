"""
Scheduling / constraint satisfaction solver adapter.

Handles: shift rostering, operating room scheduling, task sequencing,
appointment booking, warehouse pick scheduling.

Uses a greedy + swap heuristic for general scheduling.
OR-Tools CP-SAT for constraint satisfaction when available.
"""

import time
from typing import Any
from copy import deepcopy

from ..base import (
    SolverAdapter, SolverCategory, SolverResult, SolveStatus, ProblemSpec,
)

try:
    from ortools.sat.python import cp_model
    HAS_CPSAT = True
except ImportError:
    HAS_CPSAT = False


class SchedulingAdapter(SolverAdapter):
    """
    Constraint-based scheduling solver.

    Expects problem.tasks and problem.resources:

    tasks: [
        {"id": "surgery_1", "duration": 120, "priority": 3,
         "required_resources": ["surgeon", "or_room"],
         "earliest_start": 480, "latest_end": 1020,
         "dependencies": ["prep_1"]},
    ]

    resources: [
        {"id": "dr_chen", "type": "surgeon", "capacity": 1,
         "available_from": 420, "available_until": 1020},
        {"id": "or_1", "type": "or_room", "capacity": 1,
         "available_from": 360, "available_until": 1080},
    ]
    """

    name = "scheduling"
    display_name = "Constraint-based scheduling"
    category = SolverCategory.COMBINATORIAL
    description = "Shift rostering, OR scheduling, task sequencing"
    supported_problem_types = [
        "shift_scheduling",
        "or_scheduling",
        "task_scheduling",
        "appointment_booking",
        "pick_scheduling",
    ]

    def configurable_params(self) -> list[dict[str, Any]]:
        return [
            {"name": "time_limit_seconds", "type": "float", "min": 5, "max": 120, "default": 30, "label": "Time limit (s)"},
            {"name": "allow_overtime", "type": "bool", "default": False, "label": "Allow overtime"},
            {"name": "priority_weight", "type": "float", "min": 0, "max": 10, "default": 1.0, "label": "Priority weight"},
        ]

    async def solve(self, problem: ProblemSpec) -> SolverResult:
        start = time.time()

        tasks = problem.tasks or []
        resources = problem.resources or []

        if not tasks:
            return SolverResult(
                status=SolveStatus.ERROR,
                solver_name=self.name,
                explanation="No tasks provided for scheduling",
            )

        try:
            if HAS_CPSAT and len(tasks) > 2:
                result = self._solve_cpsat(tasks, resources, problem)
            else:
                result = self._solve_greedy(tasks, resources, problem)
        except Exception as e:
            return SolverResult(
                status=SolveStatus.ERROR,
                solver_name=self.name,
                solve_time_seconds=time.time() - start,
                explanation=f"Scheduling error: {str(e)}",
            )

        result.solve_time_seconds = time.time() - start
        result.solver_name = self.name
        return result

    def _solve_greedy(
        self, tasks: list[dict], resources: list[dict], problem: ProblemSpec
    ) -> SolverResult:
        """Priority-based greedy scheduler with resource tracking."""
        # Sort by priority (higher first) then earliest start
        sorted_tasks = sorted(
            tasks,
            key=lambda t: (-t.get("priority", 0), t.get("earliest_start", 0)),
        )

        # Track resource availability as timeline slots
        resource_avail: dict[str, int] = {}
        for r in resources:
            resource_avail[r["id"]] = r.get("available_from", 0)

        # Resource type → resource IDs mapping
        type_to_resources: dict[str, list[str]] = {}
        for r in resources:
            rtype = r.get("type", r["id"])
            type_to_resources.setdefault(rtype, []).append(r["id"])

        schedule = []
        unscheduled = []

        for task in sorted_tasks:
            duration = task.get("duration", 60)
            earliest = task.get("earliest_start", 0)
            latest_end = task.get("latest_end", float("inf"))
            required = task.get("required_resources", [])

            # Find earliest time when all required resource types are available
            best_start = earliest
            assigned_resources = {}

            for rtype in required:
                candidates = type_to_resources.get(rtype, [])
                if not candidates:
                    break

                # Find the candidate available earliest after best_start
                best_resource = None
                best_resource_avail = float("inf")

                for rid in candidates:
                    avail = resource_avail.get(rid, 0)
                    t_start = max(avail, best_start)
                    if t_start + duration <= latest_end and t_start < best_resource_avail:
                        best_resource = rid
                        best_resource_avail = t_start

                if best_resource is None:
                    break

                assigned_resources[rtype] = best_resource
                best_start = max(best_start, resource_avail.get(best_resource, 0))
            else:
                # All resources found — schedule it
                if best_start + duration <= latest_end:
                    entry = {
                        "task": task["id"],
                        "start": best_start,
                        "end": best_start + duration,
                        "resources": assigned_resources,
                    }
                    schedule.append(entry)

                    # Update resource availability
                    for rid in assigned_resources.values():
                        resource_avail[rid] = best_start + duration
                    continue

            unscheduled.append(task["id"])

        total_priority = sum(
            next((t.get("priority", 0) for t in tasks if t["id"] == s["task"]), 0)
            for s in schedule
        )

        status = SolveStatus.OPTIMAL if not unscheduled else SolveStatus.FEASIBLE

        return SolverResult(
            status=status,
            objective_value=total_priority,
            schedule=schedule,
            solution={
                "scheduled_count": len(schedule),
                "unscheduled_count": len(unscheduled),
                "unscheduled_tasks": unscheduled,
                "total_priority_served": total_priority,
            },
        )

    def _solve_cpsat(
        self, tasks: list[dict], resources: list[dict], problem: ProblemSpec
    ) -> SolverResult:
        """Solve using OR-Tools CP-SAT solver for optimal scheduling."""
        model = cp_model.CpModel()

        # Determine time horizon
        horizon = max(
            (t.get("latest_end", 1440) for t in tasks),
            default=1440,
        )

        # Create interval variables for each task
        task_vars = {}
        for task in tasks:
            tid = task["id"]
            dur = task.get("duration", 60)
            earliest = task.get("earliest_start", 0)
            latest_end = min(task.get("latest_end", horizon), horizon)

            start_var = model.NewIntVar(earliest, latest_end - dur, f"start_{tid}")
            end_var = model.NewIntVar(earliest + dur, latest_end, f"end_{tid}")
            interval_var = model.NewIntervalVar(start_var, dur, end_var, f"interval_{tid}")

            task_vars[tid] = {
                "start": start_var,
                "end": end_var,
                "interval": interval_var,
                "duration": dur,
            }

        # Dependencies
        for task in tasks:
            tid = task["id"]
            for dep in task.get("dependencies", []):
                if dep in task_vars:
                    model.Add(task_vars[tid]["start"] >= task_vars[dep]["end"])

        # Resource constraints (no overlap on same resource)
        type_to_resources_map: dict[str, list[str]] = {}
        for r in resources:
            rtype = r.get("type", r["id"])
            type_to_resources_map.setdefault(rtype, []).append(r["id"])

        # For each resource type, collect all tasks needing it
        for task in tasks:
            for rtype in task.get("required_resources", []):
                capacity = len(type_to_resources_map.get(rtype, []))
                # Will be handled by cumulative constraint below

        # Simplified: use NoOverlap for single-capacity resources
        resource_intervals: dict[str, list] = {}
        for task in tasks:
            for rtype in task.get("required_resources", []):
                resource_intervals.setdefault(rtype, []).append(
                    task_vars[task["id"]]["interval"]
                )

        for rtype, intervals in resource_intervals.items():
            num_available = len(type_to_resources_map.get(rtype, [1]))
            if num_available == 1:
                model.AddNoOverlap(intervals)
            # For multiple resources of same type, use cumulative
            # (simplified — full implementation would assign specific resources)

        # Objective: minimise makespan (latest end time)
        makespan = model.NewIntVar(0, horizon, "makespan")
        for tid, tvars in task_vars.items():
            model.Add(makespan >= tvars["end"])
        model.Minimize(makespan)

        # Solve
        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = problem.time_limit_seconds
        status = solver.Solve(model)

        status_map = {
            cp_model.OPTIMAL: SolveStatus.OPTIMAL,
            cp_model.FEASIBLE: SolveStatus.FEASIBLE,
            cp_model.INFEASIBLE: SolveStatus.INFEASIBLE,
        }
        solve_status = status_map.get(status, SolveStatus.ERROR)

        schedule = []
        if solve_status in (SolveStatus.OPTIMAL, SolveStatus.FEASIBLE):
            for task in tasks:
                tid = task["id"]
                tvars = task_vars[tid]
                schedule.append({
                    "task": tid,
                    "start": solver.Value(tvars["start"]),
                    "end": solver.Value(tvars["end"]),
                    "resources": {},  # simplified
                })

        return SolverResult(
            status=solve_status,
            objective_value=solver.ObjectiveValue() if schedule else None,
            schedule=schedule,
            solution={"makespan": solver.ObjectiveValue() if schedule else None},
        )
