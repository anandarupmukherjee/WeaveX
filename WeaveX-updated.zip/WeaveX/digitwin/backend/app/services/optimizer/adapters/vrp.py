"""
Vehicle routing / TSP solver adapter.

Handles: delivery route optimization, fleet scheduling, patient transport
routing, warehouse pick path optimization.

Uses OR-Tools routing solver when available, falls back to a nearest-neighbor
heuristic + 2-opt improvement for environments without OR-Tools.
"""

import time
import math
from typing import Any

from ..base import (
    SolverAdapter, SolverCategory, SolverResult, SolveStatus, ProblemSpec,
)

try:
    from ortools.constraint_solver import routing_enums_pb2, pywrapcp
    HAS_ORTOOLS_ROUTING = True
except ImportError:
    HAS_ORTOOLS_ROUTING = False


class VRPAdapter(SolverAdapter):
    """
    Vehicle routing problem solver.

    Expects problem.graph to contain:
    {
        "depot": 0,                         # starting node index
        "nodes": [
            {"id": "warehouse", "x": 0, "y": 0},
            {"id": "customer_1", "x": 5, "y": 3, "demand": 10},
            ...
        ],
        "distance_matrix": [[0, 5, 8], [5, 0, 3], [8, 3, 0]],  # optional
        "num_vehicles": 3,
        "vehicle_capacity": 100,
        "time_windows": [                   # optional
            {"node": 1, "earliest": 480, "latest": 600},
        ]
    }
    """

    name = "vrp"
    display_name = "Vehicle routing (VRP/TSP)"
    category = SolverCategory.COMBINATORIAL
    description = "Route optimization for deliveries, pickups, and transport"
    supported_problem_types = [
        "vehicle_routing",
        "delivery_scheduling",
        "pickup_routing",
        "patient_transport",
        "warehouse_pick_path",
    ]
    supported_domains = ["logistics", "supply_chain", "healthcare"]

    def configurable_params(self) -> list[dict[str, Any]]:
        return [
            {"name": "time_limit_seconds", "type": "float", "min": 5, "max": 120, "default": 30, "label": "Time limit (s)"},
            {"name": "num_vehicles", "type": "int", "min": 1, "max": 50, "default": 5, "label": "Vehicles"},
            {"name": "vehicle_capacity", "type": "int", "min": 1, "max": 10000, "default": 100, "label": "Vehicle capacity"},
        ]

    async def solve(self, problem: ProblemSpec) -> SolverResult:
        start = time.time()

        if not problem.graph:
            return SolverResult(
                status=SolveStatus.ERROR,
                solver_name=self.name,
                explanation="No graph data provided for routing problem",
            )

        graph = problem.graph
        nodes = graph.get("nodes", [])

        if len(nodes) < 2:
            return SolverResult(
                status=SolveStatus.ERROR,
                solver_name=self.name,
                explanation="Need at least 2 nodes for routing",
            )

        try:
            if HAS_ORTOOLS_ROUTING and len(nodes) > 3:
                result = self._solve_ortools(problem)
            else:
                result = self._solve_heuristic(problem)
        except Exception as e:
            return SolverResult(
                status=SolveStatus.ERROR,
                solver_name=self.name,
                solve_time_seconds=time.time() - start,
                explanation=f"Routing solver error: {str(e)}",
            )

        result.solve_time_seconds = time.time() - start
        result.solver_name = self.name
        return result

    def _solve_heuristic(self, problem: ProblemSpec) -> SolverResult:
        """Nearest-neighbor heuristic with 2-opt improvement."""
        graph = problem.graph
        nodes = graph["nodes"]
        n = len(nodes)
        num_vehicles = graph.get("num_vehicles", 1)
        capacity = graph.get("vehicle_capacity", float("inf"))

        # Build distance matrix if not provided
        dist = graph.get("distance_matrix")
        if not dist:
            dist = self._build_distance_matrix(nodes)

        # Nearest-neighbor construction per vehicle
        depot = graph.get("depot", 0)
        unvisited = set(range(n)) - {depot}
        routes = []

        for v in range(num_vehicles):
            if not unvisited:
                break

            route = [depot]
            current = depot
            load = 0

            while unvisited:
                # Find nearest unvisited within capacity
                best = None
                best_dist = float("inf")

                for node in unvisited:
                    demand = nodes[node].get("demand", 0) if isinstance(nodes[node], dict) else 0
                    if load + demand <= capacity and dist[current][node] < best_dist:
                        best = node
                        best_dist = dist[current][node]

                if best is None:
                    break

                route.append(best)
                load += nodes[best].get("demand", 0) if isinstance(nodes[best], dict) else 0
                unvisited.discard(best)
                current = best

            route.append(depot)  # return to depot
            routes.append(route)

        # Apply 2-opt improvement to each route
        for i in range(len(routes)):
            routes[i] = self._two_opt(routes[i], dist)

        # Calculate total distance
        total_dist = sum(
            sum(dist[r[j]][r[j + 1]] for j in range(len(r) - 1))
            for r in routes
        )

        # Convert to node IDs
        named_routes = []
        for route in routes:
            node_ids = []
            for idx in route:
                if isinstance(nodes[idx], dict):
                    node_ids.append(nodes[idx].get("id", str(idx)))
                else:
                    node_ids.append(str(idx))
            named_routes.append(node_ids)

        return SolverResult(
            status=SolveStatus.FEASIBLE,
            objective_value=total_dist,
            routes=named_routes,
            solution={"total_distance": total_dist, "vehicles_used": len(routes)},
        )

    def _solve_ortools(self, problem: ProblemSpec) -> SolverResult:
        """Solve VRP using OR-Tools constraint solver."""
        graph = problem.graph
        nodes = graph["nodes"]
        n = len(nodes)
        num_vehicles = graph.get("num_vehicles", 1)
        depot = graph.get("depot", 0)

        # Distance matrix
        dist = graph.get("distance_matrix")
        if not dist:
            dist = self._build_distance_matrix(nodes)

        # Integer distances for OR-Tools
        int_dist = [[int(d * 100) for d in row] for row in dist]

        manager = pywrapcp.RoutingIndexManager(n, num_vehicles, depot)
        routing = pywrapcp.RoutingModel(manager)

        def distance_callback(from_index, to_index):
            from_node = manager.IndexToNode(from_index)
            to_node = manager.IndexToNode(to_index)
            return int_dist[from_node][to_node]

        transit_callback_index = routing.RegisterTransitCallback(distance_callback)
        routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

        # Capacity constraint
        capacity = graph.get("vehicle_capacity")
        if capacity:
            demands = [
                nodes[i].get("demand", 0) if isinstance(nodes[i], dict) else 0
                for i in range(n)
            ]

            def demand_callback(from_index):
                return demands[manager.IndexToNode(from_index)]

            demand_cb_index = routing.RegisterUnaryTransitCallback(demand_callback)
            routing.AddDimensionWithVehicleCapacity(
                demand_cb_index, 0, [int(capacity)] * num_vehicles, True, "Capacity"
            )

        # Solve
        search_params = pywrapcp.DefaultRoutingSearchParameters()
        search_params.first_solution_strategy = (
            routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
        )
        search_params.time_limit.seconds = int(problem.time_limit_seconds)

        assignment = routing.SolveWithParameters(search_params)

        if not assignment:
            return SolverResult(status=SolveStatus.INFEASIBLE, explanation="No feasible routes found")

        # Extract routes
        routes = []
        total_dist = 0
        for v in range(num_vehicles):
            route = []
            index = routing.Start(v)
            while not routing.IsEnd(index):
                node = manager.IndexToNode(index)
                if isinstance(nodes[node], dict):
                    route.append(nodes[node].get("id", str(node)))
                else:
                    route.append(str(node))
                prev_index = index
                index = assignment.Value(routing.NextVar(index))
                total_dist += routing.GetArcCostForVehicle(prev_index, index, v)
            # Add depot return
            node = manager.IndexToNode(index)
            route.append(nodes[node].get("id", str(node)) if isinstance(nodes[node], dict) else str(node))
            if len(route) > 2:  # skip empty routes
                routes.append(route)

        return SolverResult(
            status=SolveStatus.OPTIMAL,
            objective_value=total_dist / 100.0,
            routes=routes,
            solution={"total_distance": total_dist / 100.0, "vehicles_used": len(routes)},
        )

    @staticmethod
    def _build_distance_matrix(nodes: list) -> list[list[float]]:
        n = len(nodes)
        dist = [[0.0] * n for _ in range(n)]
        for i in range(n):
            for j in range(i + 1, n):
                ni = nodes[i] if isinstance(nodes[i], dict) else {"x": 0, "y": 0}
                nj = nodes[j] if isinstance(nodes[j], dict) else {"x": 0, "y": 0}
                d = math.sqrt(
                    (ni.get("x", 0) - nj.get("x", 0)) ** 2
                    + (ni.get("y", 0) - nj.get("y", 0)) ** 2
                )
                dist[i][j] = d
                dist[j][i] = d
        return dist

    @staticmethod
    def _two_opt(route: list[int], dist: list[list[float]]) -> list[int]:
        """2-opt local search improvement."""
        improved = True
        while improved:
            improved = False
            for i in range(1, len(route) - 2):
                for j in range(i + 1, len(route) - 1):
                    d_old = dist[route[i - 1]][route[i]] + dist[route[j]][route[j + 1]]
                    d_new = dist[route[i - 1]][route[j]] + dist[route[i]][route[j + 1]]
                    if d_new < d_old - 1e-10:
                        route[i : j + 1] = reversed(route[i : j + 1])
                        improved = True
        return route
