"""
Agent runtime — the decision loop integrating LLM reasoning with solvers.

This is where everything comes together. Each simulation round, active agents
go through their decision loop:

1. Observe: agent sees current simulation state relevant to them
2. Classify: LLM decides if this needs a solver or just reasoning
3a. If solver needed: formulate problem → dispatch to solver → interpret result
3b. If no solver: LLM reasons and produces action directly
4. Act: agent's action is applied to simulation state
5. Broadcast: action is streamed to the canvas via WebSocket

The key insight: the LLM is always in the loop. Even when a solver runs,
the LLM formulates the problem beforehand and interprets the result afterward.
The solver handles the mathematical heavy lifting; the LLM handles context.
"""

import json
import structlog
from typing import Any

from ...utils.llm_client import OllamaClient
from ...models.twin_spec import AgentSpec, BehaviourParams
from ..optimizer.registry import SolverRegistry, get_registry
from ..optimizer.problem_formulator import ProblemFormulator
from ..optimizer.base import ProblemSpec, SolverResult, SolveStatus

logger = structlog.get_logger()


class AgentAction:
    """Result of an agent's decision loop."""

    def __init__(
        self,
        agent_id: str,
        agent_name: str,
        action_type: str,
        description: str,
        details: dict[str, Any] | None = None,
        solver_used: str | None = None,
        solver_result: SolverResult | None = None,
    ):
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.action_type = action_type  # "solver_action", "llm_action", "idle"
        self.description = description
        self.details = details or {}
        self.solver_used = solver_used
        self.solver_result = solver_result

    def to_dict(self) -> dict[str, Any]:
        result = {
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "action_type": self.action_type,
            "description": self.description,
            "details": self.details,
            "solver_used": self.solver_used,
        }
        if self.solver_result:
            result["solver_status"] = self.solver_result.status.value
            result["objective_value"] = self.solver_result.objective_value
            result["solve_time"] = self.solver_result.solve_time_seconds
        return result


class AgentRuntime:
    """
    Runtime for a single agent in the simulation.

    Each agent instance has:
    - Its spec (persona, goals, tools, behaviour params)
    - A reference to the solver registry
    - A problem formulator for LLM↔solver translation
    - Assigned solvers (from canvas drag-drop)
    - Memory of recent actions and observations
    """

    def __init__(
        self,
        spec: AgentSpec,
        llm: OllamaClient | None = None,
        registry: SolverRegistry | None = None,
    ):
        self.spec = spec
        self.llm = llm or OllamaClient()
        self.registry = registry or get_registry()
        self.formulator = ProblemFormulator(self.llm)

        # Solver assignments (set from canvas UI)
        # Maps interaction_type → solver_name
        self.solver_assignments: dict[str, str] = {}

        # Short-term memory (recent observations and actions)
        self.memory: list[dict[str, Any]] = []
        self.max_memory = 20

    def assign_solver(self, interaction_type: str, solver_name: str):
        """
        Assign a solver to a specific interaction type.
        Called when user drags a solver onto this agent on the canvas.
        """
        self.solver_assignments[interaction_type] = solver_name
        logger.info(
            "Solver assigned",
            agent=self.spec.name,
            interaction=interaction_type,
            solver=solver_name,
        )

    def update_behaviour(self, params: dict[str, float]):
        """Update behaviour params from canvas sliders."""
        for key, value in params.items():
            if hasattr(self.spec.behaviour, key):
                setattr(self.spec.behaviour, key, value)

    async def decide(
        self,
        simulation_state: dict[str, Any],
        interaction_context: dict[str, Any],
        round_num: int,
    ) -> AgentAction:
        """
        Main decision loop for one agent in one simulation round.

        Args:
            simulation_state: Global sim state visible to this agent
            interaction_context: The specific interaction triggering this decision
            round_num: Current simulation round

        Returns:
            AgentAction describing what the agent does
        """
        interaction_type = interaction_context.get("type", "")

        # --- Step 1: Check if a solver is explicitly assigned for this interaction ---
        assigned_solver = self.solver_assignments.get(interaction_type)

        if assigned_solver:
            return await self._decide_with_solver(
                simulation_state, interaction_context, assigned_solver
            )

        # --- Step 2: Ask LLM if this interaction needs a solver ---
        needs_solver, problem_type = await self.formulator.classify(
            interaction_context=interaction_context,
            agent_tools=self.spec.tool_names,
        )

        if needs_solver and problem_type:
            return await self._decide_with_solver(
                simulation_state, interaction_context, solver_hint=None,
                problem_type_override=problem_type,
            )

        # --- Step 3: Pure LLM reasoning ---
        return await self._decide_with_llm(
            simulation_state, interaction_context
        )

    async def _decide_with_solver(
        self,
        state: dict[str, Any],
        context: dict[str, Any],
        solver_hint: str | None = None,
        problem_type_override: str | None = None,
    ) -> AgentAction:
        """Decision path that uses an optimisation solver."""

        problem_type = problem_type_override or context.get("type", "resource_allocation")

        # Formulate the mathematical problem
        logger.info("Formulating problem", agent=self.spec.name, type=problem_type)
        problem = await self.formulator.formulate(
            problem_type=problem_type,
            simulation_state=state,
            domain=context.get("domain", ""),
            solver_hint=solver_hint or "",
        )

        # Dispatch to solver
        result = await self.registry.solve(problem, solver_name=solver_hint)

        if result.status in (SolveStatus.OPTIMAL, SolveStatus.FEASIBLE):
            # LLM interprets the result into natural language action
            description = await self.formulator.interpret_result(
                problem=problem,
                result=result,
                agent_name=self.spec.name,
            )

            action = AgentAction(
                agent_id=self.spec.id,
                agent_name=self.spec.name,
                action_type="solver_action",
                description=description,
                details={
                    "problem_type": problem_type,
                    "assignments": result.assignments,
                    "routes": result.routes,
                    "schedule": result.schedule,
                    "equilibrium": result.equilibrium,
                },
                solver_used=result.solver_name,
                solver_result=result,
            )
        else:
            # Solver failed — fall back to LLM reasoning
            logger.warning(
                "Solver failed, falling back to LLM",
                agent=self.spec.name,
                status=result.status.value,
                reason=result.explanation,
            )
            action = await self._decide_with_llm(state, context)
            action.details["solver_fallback"] = True
            action.details["solver_failure_reason"] = result.explanation

        self._remember(action)
        return action

    async def _decide_with_llm(
        self,
        state: dict[str, Any],
        context: dict[str, Any],
    ) -> AgentAction:
        """Decision path using pure LLM reasoning (no solver)."""

        # Build the agent's system prompt from its persona
        system_prompt = f"""You are {self.spec.name}, {self.spec.persona}

Your goals: {', '.join(self.spec.goals)}
Your constraints: {', '.join(self.spec.constraints)}
Your available tools: {', '.join(self.spec.tool_names)}

Behaviour parameters:
- Activity level: {self.spec.behaviour.activity_level:.0%}
- Risk tolerance: {self.spec.behaviour.risk_tolerance:.0%}
- Compliance: {self.spec.behaviour.compliance:.0%}
- Creativity: {self.spec.behaviour.creativity:.0%}

Based on the current situation, decide what action to take.
Respond with a JSON object:
{{"action": "brief action name", "description": "2-3 sentence description of what you do", "details": {{}}}}
"""

        # Include recent memory for context
        memory_text = ""
        if self.memory:
            recent = self.memory[-5:]
            memory_text = "\nRecent actions:\n" + "\n".join(
                f"- {m['description']}" for m in recent
            )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"""Current situation:
{json.dumps(context, indent=2)}

Simulation state visible to you:
{json.dumps(state, indent=2)}
{memory_text}

What do you do?"""},
        ]

        # Adjust temperature based on creativity parameter
        temperature = 0.2 + (self.spec.behaviour.creativity * 0.6)

        result = await self.llm.chat_json(messages, temperature=temperature, max_tokens=512)

        action = AgentAction(
            agent_id=self.spec.id,
            agent_name=self.spec.name,
            action_type="llm_action",
            description=result.get("description", "No action taken"),
            details=result.get("details", {}),
        )

        self._remember(action)
        return action

    def _remember(self, action: AgentAction):
        """Add an action to short-term memory."""
        self.memory.append({
            "action": action.action_type,
            "description": action.description,
            "solver": action.solver_used,
        })
        if len(self.memory) > self.max_memory:
            self.memory = self.memory[-self.max_memory:]
