"""API routes for the optimisation toolbox — solver palette and assignments."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..services.optimizer.registry import get_registry

router = APIRouter()


@router.get("/palette")
async def get_solver_palette():
    """
    Return all available solvers for the canvas solver palette.

    The frontend renders these as draggable cards grouped by category.
    """
    registry = get_registry()
    return {
        "success": True,
        "data": registry.get_palette(),
    }


@router.get("/palette/{domain}")
async def get_domain_solvers(domain: str):
    """Get solvers filtered by domain (healthcare, logistics, supply_chain)."""
    registry = get_registry()
    return {
        "success": True,
        "data": registry.get_for_domain(domain),
    }


class SolverAssignment(BaseModel):
    agent_id: str
    interaction_type: str
    solver_name: str
    params: dict = {}


@router.post("/assign")
async def assign_solver(assignment: SolverAssignment):
    """
    Assign a solver to an agent's interaction type.

    Called when user drags a solver from the palette onto an agent node
    or interaction edge on the canvas.
    """
    registry = get_registry()
    solver = registry.get(assignment.solver_name)
    if not solver:
        raise HTTPException(404, f"Solver '{assignment.solver_name}' not found")

    # In production, this would update the simulation engine's agent runtime.
    # For now, return confirmation.
    return {
        "success": True,
        "data": {
            "agent_id": assignment.agent_id,
            "interaction_type": assignment.interaction_type,
            "solver": solver.metadata(),
        },
    }


class TestSolveRequest(BaseModel):
    problem_type: str
    domain: str = ""
    solver_name: str = ""
    state: dict = {}


@router.post("/test-solve")
async def test_solve(req: TestSolveRequest):
    """
    Test a solver with a sample problem.

    Useful for verifying solver configuration from the canvas
    before running a full simulation.
    """
    from ..services.optimizer.base import ProblemSpec
    from ..services.optimizer.problem_formulator import ProblemFormulator

    formulator = ProblemFormulator()
    problem = await formulator.formulate(
        problem_type=req.problem_type,
        simulation_state=req.state,
        domain=req.domain,
    )

    registry = get_registry()
    result = await registry.solve(problem, solver_name=req.solver_name or None)

    return {
        "success": True,
        "data": {
            "status": result.status.value,
            "objective_value": result.objective_value,
            "solve_time": result.solve_time_seconds,
            "solution": result.solution,
            "assignments": result.assignments,
            "routes": result.routes,
            "schedule": result.schedule,
            "equilibrium": result.equilibrium,
            "explanation": result.explanation,
        },
    }
