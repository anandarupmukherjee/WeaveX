"""
Domain Analyser — Multi-pass LLM extraction pipeline.

This is the core intelligence of DigiTwin. It takes parsed documents and
a user's intent, then runs four sequential LLM passes to extract everything
needed to build a digital twin:

  Pass 1: Domain ontology (entity types, relationship types)
  Pass 2: Agent extraction (specific agents with personas and goals)
  Pass 3: Interaction protocols (how agents interact)
  Pass 4: Tool & objective mapping (what tools agents need, what to optimise)

Each pass builds on the output of previous passes, progressively enriching
the twin specification.
"""

import json
import uuid
import structlog

from ...config import settings
from ...utils.llm_client import OllamaClient
from ...models.twin_spec import (
    IntentSpec, Ontology, EntityType, RelationType, EntityAttribute,
    AgentSpec, BehaviourParams, Relationship,
    InteractionProtocol, InteractionStep,
    ToolSpec, ToolParameter,
    ObjectiveSpec,
    TwinSpec,
)

logger = structlog.get_logger()

# Maximum text to send to LLM per pass (chars)
MAX_CONTEXT_CHARS = 40_000


class DomainAnalyser:
    """
    Orchestrates the multi-pass extraction pipeline.

    Usage:
        analyser = DomainAnalyser()
        twin_spec = await analyser.analyse(
            documents=["...parsed text..."],
            user_description="I want to model a hospital emergency department...",
        )
    """

    def __init__(self, llm: OllamaClient | None = None):
        self.llm = llm or OllamaClient()

    async def analyse(
        self,
        documents: list[str],
        user_description: str,
        on_progress: callable = None,
    ) -> TwinSpec:
        """
        Run the full extraction pipeline.

        Args:
            documents: List of parsed document texts
            user_description: User's natural language description of what to model
            on_progress: Optional callback(stage: str, detail: str)

        Returns:
            Complete TwinSpec ready for digital twin assembly.
        """
        combined_text = "\n\n---\n\n".join(documents)
        if len(combined_text) > MAX_CONTEXT_CHARS:
            combined_text = combined_text[:MAX_CONTEXT_CHARS]
            combined_text += f"\n\n[Truncated to {MAX_CONTEXT_CHARS} chars for analysis]"

        # --- Pass 0: Intent classification ---
        if on_progress:
            on_progress("intent", "Classifying domain and intent...")
        intent = await self._extract_intent(combined_text, user_description)
        logger.info("Intent extracted", domain=intent.domain, model_type=intent.model_type)

        # --- Pass 1: Ontology ---
        if on_progress:
            on_progress("ontology", "Extracting domain ontology...")
        ontology = await self._extract_ontology(combined_text, intent)
        logger.info(
            "Ontology extracted",
            entity_types=len(ontology.entity_types),
            relation_types=len(ontology.relation_types),
        )

        # --- Pass 2: Agents ---
        if on_progress:
            on_progress("agents", "Identifying agents and personas...")
        agents = await self._extract_agents(combined_text, intent, ontology)
        logger.info("Agents extracted", count=len(agents))

        # --- Pass 3: Interactions ---
        if on_progress:
            on_progress("interactions", "Mapping interaction protocols...")
        interactions = await self._extract_interactions(combined_text, intent, agents)
        logger.info("Interactions extracted", count=len(interactions))

        # --- Pass 4: Tools & Objectives ---
        if on_progress:
            on_progress("tools", "Assigning tools and objectives...")
        tools = await self._map_tools(intent, agents, interactions)
        objectives = await self._map_objectives(intent, agents, interactions)
        logger.info("Tools mapped", tools=len(tools), objectives=len(objectives))

        return TwinSpec(
            intent=intent,
            ontology=ontology,
            agents=agents,
            interactions=interactions,
            tools=tools,
            objectives=objectives,
        )

    # ================================================================
    # Pass 0: Intent Classification
    # ================================================================

    async def _extract_intent(self, text: str, user_desc: str) -> IntentSpec:
        messages = [
            {
                "role": "system",
                "content": """You are an expert at analysing documents and user requirements
to determine what kind of system or process needs to be modelled as a digital twin.

Respond with ONLY a JSON object matching this schema:
{
  "domain": "short_snake_case_domain_name",
  "domain_description": "One sentence describing the domain",
  "model_type": "process" | "organisation" | "market" | "system",
  "optimisation_targets": ["metric_1", "metric_2"],
  "scenario_seeds": ["scenario_1", "scenario_2"],
  "constraints": ["constraint_1"]
}

Choose model_type based on what the user primarily wants to simulate:
- "process": sequential workflows, pipelines, patient journeys
- "organisation": team dynamics, reporting structures, decision making
- "market": supply/demand, competition, pricing, trading
- "system": technical systems, infrastructure, networks"""
            },
            {
                "role": "user",
                "content": f"""## User's description
{user_desc}

## Reference documents (excerpt)
{text[:8000]}

Analyse the above and classify the domain, model type, what should be
optimised, what scenarios to explore, and any constraints."""
            },
        ]

        result = await self.llm.chat_json(messages, temperature=0.2)
        return IntentSpec(**result)

    # ================================================================
    # Pass 1: Ontology Extraction
    # ================================================================

    async def _extract_ontology(self, text: str, intent: IntentSpec) -> Ontology:
        messages = [
            {
                "role": "system",
                "content": f"""You are an expert knowledge graph ontology designer.
Your task: design entity types and relationship types for a digital twin
simulation in the "{intent.domain}" domain ({intent.domain_description}).

This is a {intent.model_type} model. The entities must be CONCRETE actors
or objects that can take actions in a simulation — not abstract concepts.

Respond with ONLY a JSON object:
{{
  "entity_types": [
    {{
      "name": "PascalCaseName",
      "description": "What this entity represents (max 100 chars)",
      "attributes": [
        {{"name": "snake_case_attr", "type": "text", "description": "..."}}
      ],
      "examples": ["Example1", "Example2"]
    }}
  ],
  "relation_types": [
    {{
      "name": "UPPER_SNAKE_CASE",
      "description": "What this relationship means",
      "source_type": "EntityTypeName",
      "target_type": "EntityTypeName"
    }}
  ],
  "analysis_summary": "Brief summary of the domain structure"
}}

RULES:
- Design 5-15 entity types appropriate for the domain (NOT hardcoded)
- Design 5-12 relationship types
- Entity types must be concrete: people, machines, locations, resources
- NOT abstract: "quality", "efficiency", "risk" are not entity types
- Attributes: 1-4 per entity, names in snake_case
- Do NOT use reserved attribute names: name, uuid, id, created_at"""
            },
            {
                "role": "user",
                "content": f"""## Domain: {intent.domain}
## Model type: {intent.model_type}
## Optimisation targets: {', '.join(intent.optimisation_targets)}

## Document content
{text[:20000]}

Design the ontology for this digital twin."""
            },
        ]

        result = await self.llm.chat_json(messages, temperature=0.3)

        # Parse into models
        entity_types = [EntityType(**et) for et in result.get("entity_types", [])]
        relation_types = [RelationType(**rt) for rt in result.get("relation_types", [])]

        return Ontology(
            entity_types=entity_types,
            relation_types=relation_types,
            analysis_summary=result.get("analysis_summary", ""),
        )

    # ================================================================
    # Pass 2: Agent Extraction
    # ================================================================

    async def _extract_agents(
        self, text: str, intent: IntentSpec, ontology: Ontology
    ) -> list[AgentSpec]:
        entity_type_names = [et.name for et in ontology.entity_types]
        entity_descriptions = "\n".join(
            f"- {et.name}: {et.description}" for et in ontology.entity_types
        )

        messages = [
            {
                "role": "system",
                "content": f"""You are building a digital twin simulation for "{intent.domain}".
The ontology has these entity types:
{entity_descriptions}

Extract specific agents from the documents. Each agent is an instance of
an entity type — a concrete actor in the simulation with their own persona,
goals, and behaviour.

Respond with ONLY a JSON object:
{{
  "agents": [
    {{
      "name": "Dr. Sarah Chen",
      "entity_type": "Doctor",
      "persona": "Senior emergency physician, 15 years experience, methodical...",
      "goals": ["minimise patient wait time", "ensure accurate diagnoses"],
      "constraints": ["max 12-hour shifts", "must follow triage protocol"],
      "tool_names": ["check_patient_history", "order_lab_test"],
      "behaviour": {{
        "activity_level": 0.8,
        "response_latency": 0.3,
        "risk_tolerance": 0.4,
        "compliance": 0.9,
        "creativity": 0.3
      }},
      "relationships": [
        {{
          "target_agent_name": "Nurse Williams",
          "relation_type": "WORKS_WITH",
          "description": "Primary nursing support",
          "weight": 0.9
        }}
      ],
      "properties": {{}}
    }}
  ]
}}

RULES:
- Extract 8-30 agents depending on domain complexity
- entity_type MUST be one of: {', '.join(entity_type_names)}
- Personas should be detailed (2-4 sentences) and distinct
- Goals should relate to the domain's optimisation targets
- tool_names: list tool names the agent would logically need
- behaviour values: 0.0-1.0, make them varied and realistic
- relationships: who this agent interacts with, by target name"""
            },
            {
                "role": "user",
                "content": f"""## Document content
{text[:20000]}

## Optimisation targets: {', '.join(intent.optimisation_targets)}

Extract all agents for the digital twin simulation."""
            },
        ]

        result = await self.llm.chat_json(messages, temperature=0.4, max_tokens=8192)

        agents = []
        name_to_id = {}

        for raw in result.get("agents", []):
            agent_id = f"agent_{uuid.uuid4().hex[:8]}"
            name_to_id[raw["name"]] = agent_id

            # Parse relationships (resolve names to IDs later)
            relationships = []
            for rel in raw.get("relationships", []):
                relationships.append(Relationship(
                    target_agent_id=rel.get("target_agent_name", ""),  # resolve later
                    relation_type=rel.get("relation_type", "INTERACTS_WITH"),
                    description=rel.get("description", ""),
                    weight=rel.get("weight", 1.0),
                ))

            agents.append(AgentSpec(
                id=agent_id,
                name=raw["name"],
                entity_type=raw.get("entity_type", "Unknown"),
                persona=raw.get("persona", ""),
                goals=raw.get("goals", []),
                constraints=raw.get("constraints", []),
                tool_names=raw.get("tool_names", []),
                behaviour=BehaviourParams(**raw.get("behaviour", {})),
                relationships=relationships,
                properties=raw.get("properties", {}),
            ))

        # Resolve relationship target names to IDs
        for agent in agents:
            for rel in agent.relationships:
                if rel.target_agent_id in name_to_id:
                    rel.target_agent_id = name_to_id[rel.target_agent_id]

        return agents

    # ================================================================
    # Pass 3: Interaction Protocol Extraction
    # ================================================================

    async def _extract_interactions(
        self, text: str, intent: IntentSpec, agents: list[AgentSpec]
    ) -> list[InteractionProtocol]:
        agent_summary = "\n".join(
            f"- {a.name} ({a.entity_type}): {a.goals[0] if a.goals else 'general'}"
            for a in agents
        )

        messages = [
            {
                "role": "system",
                "content": f"""You are designing interaction protocols for a digital twin
simulation in the "{intent.domain}" domain.

Available agents:
{agent_summary}

Extract the key interaction patterns — how agents work together, communicate,
and trigger each other's actions.

Respond with ONLY a JSON object:
{{
  "interactions": [
    {{
      "name": "Patient Triage Flow",
      "description": "How a new patient is assessed and routed",
      "trigger": "New patient arrives at reception",
      "participant_names": ["Receptionist", "Triage Nurse", "Doctor"],
      "steps": [
        {{
          "actor": "Receptionist",
          "action": "Records patient details and symptoms",
          "tools_used": ["register_patient"],
          "produces": "patient_record"
        }}
      ],
      "frequency": "per_event"
    }}
  ]
}}

RULES:
- Extract 5-15 interaction protocols
- participant_names must match agent names from the list above
- Each protocol should have 2-6 steps
- frequency: "per_event", "hourly", "daily", "weekly", "continuous"
- steps should reference realistic tools"""
            },
            {
                "role": "user",
                "content": f"""## Document content (excerpt)
{text[:15000]}

Extract the interaction protocols for this simulation."""
            },
        ]

        result = await self.llm.chat_json(messages, temperature=0.3, max_tokens=8192)

        # Build name→id lookup
        name_to_id = {a.name: a.id for a in agents}

        interactions = []
        for raw in result.get("interactions", []):
            participant_ids = [
                name_to_id.get(n, n) for n in raw.get("participant_names", [])
            ]
            steps = [
                InteractionStep(**s) for s in raw.get("steps", [])
            ]
            interactions.append(InteractionProtocol(
                id=f"proto_{uuid.uuid4().hex[:8]}",
                name=raw["name"],
                description=raw.get("description", ""),
                trigger=raw.get("trigger", ""),
                participants=participant_ids,
                steps=steps,
                frequency=raw.get("frequency", "per_event"),
            ))

        return interactions

    # ================================================================
    # Pass 4a: Tool Mapping
    # ================================================================

    async def _map_tools(
        self, intent: IntentSpec, agents: list[AgentSpec],
        interactions: list[InteractionProtocol],
    ) -> list[ToolSpec]:
        # Collect all tool names referenced by agents and interactions
        all_tool_names = set()
        for a in agents:
            all_tool_names.update(a.tool_names)
        for proto in interactions:
            for step in proto.steps:
                all_tool_names.update(step.tools_used)

        messages = [
            {
                "role": "system",
                "content": f"""You are designing the tool specifications for a digital twin
simulation in the "{intent.domain}" domain.

The following tool names were referenced by agents and interaction protocols:
{json.dumps(sorted(all_tool_names), indent=2)}

For each tool, provide a precise specification. Also add any additional tools
that agents would logically need but weren't explicitly mentioned.

Respond with ONLY a JSON object:
{{
  "tools": [
    {{
      "name": "check_patient_history",
      "description": "Retrieve a patient's medical history and past visits",
      "parameters": [
        {{"name": "patient_id", "type": "string", "description": "Patient identifier", "required": true}}
      ],
      "domain": "{intent.domain}",
      "side_effects": ["reads_database"]
    }}
  ]
}}"""
            },
            {
                "role": "user",
                "content": "Generate complete tool specifications for all tools needed.",
            },
        ]

        result = await self.llm.chat_json(messages, temperature=0.2, max_tokens=8192)

        return [
            ToolSpec(
                name=t["name"],
                description=t.get("description", ""),
                parameters=[ToolParameter(**p) for p in t.get("parameters", [])],
                domain=t.get("domain", intent.domain),
                side_effects=t.get("side_effects", []),
            )
            for t in result.get("tools", [])
        ]

    # ================================================================
    # Pass 4b: Objective Mapping
    # ================================================================

    async def _map_objectives(
        self, intent: IntentSpec, agents: list[AgentSpec],
        interactions: list[InteractionProtocol],
    ) -> list[ObjectiveSpec]:
        messages = [
            {
                "role": "system",
                "content": f"""Define measurable optimisation objectives for a digital twin
simulation in the "{intent.domain}" domain.

The user wants to optimise: {', '.join(intent.optimisation_targets)}
Constraints: {', '.join(intent.constraints)}

Respond with ONLY a JSON object:
{{
  "objectives": [
    {{
      "name": "Reduce patient wait time",
      "description": "Minimise average time from arrival to first doctor contact",
      "kpi": "avg_wait_minutes",
      "target_direction": "minimize",
      "collection_point": "After triage nurse assessment completes"
    }}
  ]
}}"""
            },
            {
                "role": "user",
                "content": "Define the objectives and KPIs.",
            },
        ]

        result = await self.llm.chat_json(messages, temperature=0.2)

        return [
            ObjectiveSpec(**obj)
            for obj in result.get("objectives", [])
        ]
