"""Document analysis / extraction API routes."""

import os
import uuid
import shutil
from pathlib import Path

from fastapi import APIRouter, UploadFile, File, Form, HTTPException
import structlog

from ..config import settings
from ..services.extractors.document_parser import parse_multiple, SUPPORTED_EXTENSIONS
from ..services.extractors.domain_analyser import DomainAnalyser
from ..models.twin_spec import TwinSpec

router = APIRouter()
logger = structlog.get_logger()

# Store extraction results in memory for dev
_extractions: dict[str, TwinSpec] = {}


@router.post("/upload-and-analyse")
async def upload_and_analyse(
    files: list[UploadFile] = File(...),
    description: str = Form(...),
    project_id: str = Form(""),
):
    """
    Upload reference documents and run the full extraction pipeline.

    This is the main entry point. It:
    1. Saves uploaded files
    2. Parses them into text
    3. Runs the 4-pass LLM domain analysis
    4. Returns the complete TwinSpec

    Expects multipart form data with files + a text description.
    """
    if not files:
        raise HTTPException(400, "No files uploaded")

    # Save uploaded files
    extraction_id = f"ext_{uuid.uuid4().hex[:12]}"
    upload_dir = settings.upload_path / extraction_id
    upload_dir.mkdir(parents=True, exist_ok=True)

    saved_paths = []
    for f in files:
        ext = Path(f.filename).suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            logger.warning("Skipping unsupported file", filename=f.filename, ext=ext)
            continue

        dest = upload_dir / f.filename
        with open(dest, "wb") as out:
            content = await f.read()
            out.write(content)
        saved_paths.append(str(dest))
        logger.info("Saved upload", filename=f.filename, size=len(content))

    if not saved_paths:
        raise HTTPException(400, "No supported files found in upload")

    # Parse documents
    documents = parse_multiple(saved_paths)
    logger.info("Parsed documents", count=len(documents), total_chars=sum(len(d) for d in documents))

    # Run extraction pipeline
    analyser = DomainAnalyser()
    try:
        twin_spec = await analyser.analyse(
            documents=documents,
            user_description=description,
        )
    except Exception as e:
        logger.error("Extraction failed", error=str(e))
        raise HTTPException(500, f"Analysis failed: {str(e)}")

    _extractions[extraction_id] = twin_spec

    return {
        "success": True,
        "extraction_id": extraction_id,
        "data": twin_spec.model_dump(),
    }


@router.get("/{extraction_id}")
async def get_extraction(extraction_id: str):
    """Retrieve a previous extraction result."""
    spec = _extractions.get(extraction_id)
    if not spec:
        raise HTTPException(404, "Extraction not found")
    return {"success": True, "data": spec.model_dump()}


@router.post("/analyse-text")
async def analyse_text(
    text: str = Form(...),
    description: str = Form(...),
):
    """
    Analyse raw text (no file upload needed).
    Useful for testing or pasting content directly.
    """
    analyser = DomainAnalyser()
    try:
        twin_spec = await analyser.analyse(
            documents=[text],
            user_description=description,
        )
    except Exception as e:
        raise HTTPException(500, f"Analysis failed: {str(e)}")

    extraction_id = f"ext_{uuid.uuid4().hex[:12]}"
    _extractions[extraction_id] = twin_spec

    return {
        "success": True,
        "extraction_id": extraction_id,
        "data": twin_spec.model_dump(),
    }
