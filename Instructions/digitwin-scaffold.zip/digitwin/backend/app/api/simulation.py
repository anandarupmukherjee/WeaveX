"""Simulation control API routes — stub for milestone 3."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()


class StartSimRequest(BaseModel):
    extraction_id: str
    rounds: int = 50
    time_step_minutes: int = 60


@router.post("/start")
async def start_simulation(req: StartSimRequest):
    """Start a simulation from an extraction result."""
    # TODO: Milestone 3 — implement simulation engine
    return {
        "success": True,
        "message": "Simulation engine not yet implemented (milestone 3)",
        "simulation_id": "sim_placeholder",
    }


@router.post("/{sim_id}/pause")
async def pause_simulation(sim_id: str):
    return {"success": True, "message": "Paused (stub)"}


@router.post("/{sim_id}/resume")
async def resume_simulation(sim_id: str):
    return {"success": True, "message": "Resumed (stub)"}


@router.post("/{sim_id}/inject-event")
async def inject_event(sim_id: str, event: dict):
    """Inject a scenario event into a running simulation."""
    return {"success": True, "message": "Event injected (stub)"}


@router.get("/{sim_id}/status")
async def simulation_status(sim_id: str):
    return {"status": "not_implemented", "round": 0, "total_rounds": 0}
