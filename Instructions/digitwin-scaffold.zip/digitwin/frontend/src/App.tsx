import { useAppStore } from "./stores/appStore";
import UploadPanel from "./components/panels/UploadPanel";
import TwinCanvas from "./components/canvas/TwinCanvas";

export default function App() {
  const phase = useAppStore((s) => s.phase);
  const twinSpec = useAppStore((s) => s.twinSpec);
  const analysisStage = useAppStore((s) => s.analysisStage);
  const analysisDetail = useAppStore((s) => s.analysisDetail);

  return (
    <div className="h-screen w-screen flex flex-col bg-zinc-950 text-zinc-100">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-3 border-b border-zinc-800 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-sm font-bold">
            DT
          </div>
          <h1 className="text-lg font-semibold">DigiTwin</h1>
        </div>
        <div className="flex items-center gap-4 text-sm text-zinc-400">
          <span
            className={
              phase === "upload" ? "text-indigo-400 font-medium" : ""
            }
          >
            1. Upload
          </span>
          <span className="text-zinc-600">→</span>
          <span
            className={
              phase === "analysing" ? "text-indigo-400 font-medium" : ""
            }
          >
            2. Analyse
          </span>
          <span className="text-zinc-600">→</span>
          <span
            className={
              phase === "review" ? "text-indigo-400 font-medium" : ""
            }
          >
            3. Review
          </span>
          <span className="text-zinc-600">→</span>
          <span
            className={
              phase === "canvas" || phase === "simulating"
                ? "text-indigo-400 font-medium"
                : ""
            }
          >
            4. Sandbox
          </span>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 overflow-hidden">
        {phase === "upload" && <UploadPanel />}

        {phase === "analysing" && (
          <div className="flex flex-col items-center justify-center h-full gap-4">
            <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-lg font-medium">Analysing documents...</p>
            <p className="text-sm text-zinc-400">
              {analysisStage && `${analysisStage}: `}
              {analysisDetail}
            </p>
            <p className="text-xs text-zinc-500 mt-2">
              This may take 1-3 minutes with a local Gemma 4 model
            </p>
          </div>
        )}

        {phase === "review" && twinSpec && (
          <div className="h-full flex flex-col">
            <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold">
                  Extraction complete — {twinSpec.intent.domain}
                </h2>
                <p className="text-sm text-zinc-400 mt-1">
                  {twinSpec.agents.length} agents ·{" "}
                  {twinSpec.interactions.length} interactions ·{" "}
                  {twinSpec.tools.length} tools ·{" "}
                  {twinSpec.objectives.length} objectives
                </p>
              </div>
              <button
                onClick={() => useAppStore.getState().setPhase("canvas")}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded-lg font-medium transition-colors"
              >
                Open sandbox →
              </button>
            </div>
            <div className="flex-1 overflow-auto p-6">
              <pre className="text-xs text-zinc-300 bg-zinc-900 rounded-lg p-4 overflow-auto max-h-[70vh]">
                {JSON.stringify(twinSpec, null, 2)}
              </pre>
            </div>
          </div>
        )}

        {(phase === "canvas" || phase === "simulating") && twinSpec && (
          <TwinCanvas twinSpec={twinSpec} />
        )}
      </main>
    </div>
  );
}
