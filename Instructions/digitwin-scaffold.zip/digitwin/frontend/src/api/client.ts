import axios from "axios";
import type { TwinSpec } from "../types";

const api = axios.create({
  baseURL: "/api",
  timeout: 300_000, // 5 min — extraction can be slow with local LLM
});

/* --- Extraction --- */

export async function uploadAndAnalyse(
  files: File[],
  description: string,
  projectId?: string
): Promise<{ extraction_id: string; data: TwinSpec }> {
  const form = new FormData();
  files.forEach((f) => form.append("files", f));
  form.append("description", description);
  if (projectId) form.append("project_id", projectId);

  const res = await api.post("/extract/upload-and-analyse", form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return res.data;
}

export async function analyseText(
  text: string,
  description: string
): Promise<{ extraction_id: string; data: TwinSpec }> {
  const form = new FormData();
  form.append("text", text);
  form.append("description", description);
  const res = await api.post("/extract/analyse-text", form);
  return res.data;
}

export async function getExtraction(
  id: string
): Promise<{ data: TwinSpec }> {
  const res = await api.get(`/extract/${id}`);
  return res.data;
}

/* --- Projects --- */

export async function createProject(name: string) {
  const res = await api.post("/projects/", { name });
  return res.data;
}

export async function listProjects() {
  const res = await api.get("/projects/");
  return res.data;
}

/* --- Simulation --- */

export async function startSimulation(extractionId: string, rounds = 50) {
  const res = await api.post("/simulation/start", {
    extraction_id: extractionId,
    rounds,
  });
  return res.data;
}

/* --- WebSocket --- */

export function connectSimulationWS(
  simId: string,
  onMessage: (event: Record<string, unknown>) => void
): WebSocket {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const ws = new WebSocket(`${protocol}//${window.location.host}/ws/simulation/${simId}`);

  ws.onmessage = (e) => {
    try {
      const data = JSON.parse(e.data);
      onMessage(data);
    } catch {
      console.warn("Non-JSON WS message:", e.data);
    }
  };

  ws.onerror = (e) => console.error("WS error:", e);
  return ws;
}

export default api;
